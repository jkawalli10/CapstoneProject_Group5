"""Sentiment tests that never call Claude (offline engine + baseline only)."""
import pandas as pd

from src.analysis import sentiment as sa
from src.llmops.llm_client import get_client
from src.schema import stars_to_label


def sample_df():
    return pd.DataFrame({
        "review_id": ["1", "2", "3", "4", "5", "6", "7", "8"],
        "review_text": [
            "Great product, works perfectly and arrived fast!",
            "Excellent quality, I love it and would recommend.",
            "Poor quality, it broke after two days.",
            "Terrible, arrived late and damaged, want a refund.",
            "It is okay, does the job but nothing special.",
            "Average product, fine for the price.",
            "Amazing, best purchase this year.",
            "Awful, stopped working, very disappointed.",
        ],
        "rating": [5, 5, 1, 1, 3, 3, 5, 2],
        "detected_language": ["en"] * 8,
        "translated_text": [None] * 8,
    })


def test_stars_to_label_mapping():
    assert stars_to_label(1) == "negative" and stars_to_label(3) == "neutral" and stars_to_label(5) == "positive"


def test_offline_classifier_returns_valid_labels():
    df = sa.classify_llm(sample_df(), client=get_client(force_offline=True), use_tracking=False)
    assert set(df.sentiment) <= {"negative", "neutral", "positive"}
    assert df.topic.notna().all()
    assert df.stars_estimate.between(1, 5).all()


def test_offline_classifier_gets_clear_cases_right():
    df = sa.classify_llm(sample_df(), client=get_client(force_offline=True), use_tracking=False)
    assert df.loc[df.review_id == "1", "sentiment"].iloc[0] == "positive"
    assert df.loc[df.review_id == "4", "sentiment"].iloc[0] == "negative"


def test_baseline_trains_and_predicts():
    df = sample_df()
    pipe, text_col = sa.train_baseline(df)
    out = sa.predict_baseline(pipe, df, text_col)
    assert "baseline_sentiment" in out.columns
    assert set(out.baseline_sentiment) <= {"negative", "neutral", "positive"}


def test_stacker_trains_and_predicts():
    df = sa.classify_llm(sample_df(), client=get_client(force_offline=True), use_tracking=False)
    pipe, text_col = sa.train_baseline(df)
    df = sa.predict_baseline(pipe, df, text_col)
    df["truth"] = df["rating"].apply(lambda r: stars_to_label(int(r)))
    clf = sa.train_stacker(df)
    out = sa.predict_stacker(clf, df)
    assert "stacked_sentiment" in out.columns
    assert out.stacked_confidence.between(0, 1).all()


def test_evaluate_reports_accuracy_and_confusion():
    pred = pd.Series(["positive", "negative", "neutral", "positive"])
    truth = pd.Series(["positive", "negative", "neutral", "negative"])
    m = sa.evaluate(pred, truth)
    assert m["n"] == 4 and m["accuracy"] == 0.75 and "confusion" in m
