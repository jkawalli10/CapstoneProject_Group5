"""Ingestion + schema tests (no network, no API)."""
import pandas as pd

from src.ingestion import loader
from src.schema import UNIFIED_COLUMNS, Review, stars_to_label


def test_unified_columns_are_stable():
    assert UNIFIED_COLUMNS == ["review_id", "source", "product_category", "rating", "review_text",
                               "detected_language", "translated_text", "review_date"]


def test_review_dataclass_to_dict_has_no_extra():
    r = Review(review_id="1", source="test", review_text="hello", rating=5)
    d = r.to_dict()
    assert "extra" not in d and d["review_id"] == "1" and d["rating"] == 5


def test_to_unified_normalises_arbitrary_rows():
    df = loader.to_unified([{"id": "a", "text": "great", "rating": 5, "language": "en"}])
    assert list(df.columns) == UNIFIED_COLUMNS
    assert df.iloc[0]["review_id"] == "a" and df.iloc[0]["review_text"] == "great"


def test_load_csv_renames_common_columns(tmp_path):
    p = tmp_path / "r.csv"
    pd.DataFrame({"id": ["1"], "text": ["ok"], "stars": [4], "language": ["en"]}).to_csv(p, index=False)
    df = loader.load_csv(p)
    assert df.iloc[0]["review_id"] == "1" and df.iloc[0]["rating"] == 4


def test_stars_to_label_edges():
    assert [stars_to_label(s) for s in (1, 2, 3, 4, 5)] == ["negative", "negative", "neutral", "positive", "positive"]
