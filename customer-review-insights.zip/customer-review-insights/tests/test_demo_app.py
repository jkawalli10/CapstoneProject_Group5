"""Demo app tests: no Claude calls (the offline engine serves the live tab)."""
import pytest

pytest.importorskip("gradio")

import app  # noqa: E402


def test_saved_examples_load_and_render():
    labels = app.example_labels()
    assert len(labels) == len(app.EXAMPLES) >= 10
    review, analysis, reply, judge, _ = app.show_example(labels[0])
    assert review and reply
    assert "Sentiment" in analysis and "Status" in judge


def test_saved_examples_cover_six_languages():
    assert {e["language"] for e in app.EXAMPLES} == set(app.LANG)


def test_negative_examples_always_wait_for_a_human():
    assert all(e["status"] == "pending_human_review" for e in app.EXAMPLES if e["sentiment"] == "negative")


def test_spike_tab_finds_the_dashboard_alerts():
    table, weekly = app.run_spikes(3.5, 8)
    assert len(table) >= 1
    assert "z" in table.columns
    assert set(weekly["week"]) <= {f"W{i:02d}" for i in range(1, 13)}


def test_spike_tab_stricter_threshold_finds_fewer():
    loose, _ = app.run_spikes(3.5, 8)
    strict, _ = app.run_spikes(6.0, 15)
    assert len(strict) <= len(loose)


def test_live_tab_guards_do_not_call_claude(monkeypatch):
    monkeypatch.delenv("DEMO_ACCESS_CODE", raising=False)
    assert "Paste a review" in app.analyse_live("  ", "", True, "", 0)[3]
    assert "live requests" in app.analyse_live("late parcel", "", True, "", app.MAX_CALLS)[3]
    monkeypatch.setenv("DEMO_ACCESS_CODE", "secret")
    assert "access code" in app.analyse_live("late parcel", "", True, "wrong", 0)[3]


def test_live_tab_runs_offline_without_a_key(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("DEMO_ACCESS_CODE", raising=False)
    monkeypatch.setenv("OFFLINE", "1")
    analysis, reply, status, note, used = app.analyse_live("The product arrived late and was damaged.", "", True, "", 0)
    assert reply and "Sentiment" in analysis
    assert used == 1
