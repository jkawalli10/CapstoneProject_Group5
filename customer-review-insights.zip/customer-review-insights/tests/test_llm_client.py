"""Tests for the offline engine and the LLMOps tracking wrapper (no API calls)."""
import json

import pytest

from src.llmops import tracking
from src.llmops.llm_client import OfflineEngine, detect_language, get_client, parse_json, text_of


def test_offline_client_is_used_without_a_key():
    client = get_client(force_offline=True)
    assert client.offline is True


def test_detect_language_covers_the_six_languages():
    assert detect_language("This is a great product") == "en"
    assert detect_language("Das Produkt ist sehr gut und nicht teuer") == "de"
    assert detect_language("El producto es muy bueno pero caro") == "es"
    assert detect_language("Le produit est très bon mais pas parfait") == "fr"
    assert detect_language("この製品は最高です") == "ja"
    assert detect_language("这个产品质量很好") == "zh"


def test_offline_translation_prompt_returns_expected_shape():
    engine = OfflineEngine()
    resp = engine.create(model="x", system="You are a professional translator for reviews.",
                         messages=[{"role": "user", "content": json.dumps([{"id": "1", "text": "Sehr gut"}])}])
    body = parse_json(text_of(resp))
    assert body["translations"][0]["id"] == "1"
    assert body["translations"][0]["language"] == "de"


def test_offline_classification_prompt_returns_expected_shape():
    engine = OfflineEngine()
    resp = engine.create(model="x", system="You are a customer-experience analyst who classifies reviews.",
                         messages=[{"role": "user", "content": json.dumps([{"id": "1", "text": "broke after a day"}])}])
    c = parse_json(text_of(resp))["classifications"][0]
    assert c["sentiment"] == "negative" and 1 <= c["stars"] <= 5


def test_offline_reply_prompt_returns_a_reply():
    engine = OfflineEngine()
    resp = engine.create(model="x", system="You write public replies to customer reviews.",
                         messages=[{"role": "user", "content": json.dumps(
                             {"review": "arrived late", "sentiment": "negative", "issue": "arrived late"})}])
    assert "reply" in parse_json(text_of(resp))


def test_parse_json_tolerates_code_fences():
    assert parse_json('```json\n{"a": 1}\n```') == {"a": 1}


def test_tracking_logs_a_call(tmp_path, monkeypatch):
    monkeypatch.setattr(tracking, "LOG", tmp_path / "calls.jsonl")
    client = tracking.TrackedClient(get_client(force_offline=True), "test", "v1")
    client.messages.create(model="claude-haiku-4-5", system="You are a professional translator.",
                           messages=[{"role": "user", "content": json.dumps([{"id": "1", "text": "hola"}])}])
    rec = json.loads((tmp_path / "calls.jsonl").read_text().splitlines()[0])
    assert rec["purpose"] == "test" and rec["prompt_version"] == "v1" and rec["offline"] is True
    assert rec["cost_usd"] == 0.0


def test_spend_cap_raises(tmp_path, monkeypatch):
    monkeypatch.setattr(tracking, "LOG", tmp_path / "calls.jsonl")
    monkeypatch.setenv("MAX_SPEND_USD", "0.01")
    (tmp_path / "calls.jsonl").write_text('{"cost_usd": 0.02}\n', encoding="utf-8")
    with pytest.raises(tracking.BudgetExceeded):
        tracking.TrackedClient(object(), "x", "v0").create(model="claude-haiku-4-5")
