"""Response generation + judge tests using the offline engine (no API calls)."""
import pandas as pd

from src.llmops.llm_client import get_client
from src.response import generate as gen
from src.response import judge as jd


def sample_df():
    return pd.DataFrame({
        "review_id": ["1", "2", "3"],
        "review_text": ["The product arrived late and was damaged.",
                        "Excellent quality, I love it.",
                        "It is okay, does the job."],
        "sentiment": ["negative", "positive", "neutral"],
        "topic": ["shipping", "quality", "other"],
        "issue": ["arrived late", None, None],
        "detected_language": ["en", "en", "en"],
        "customer_name": [None, None, None],
    })


def test_playbook_grid_is_complete():
    assets = gen.load_assets()
    for sentiment in ("positive", "neutral", "negative"):
        for topic in ("shipping", "quality", "support", "features", "price", "ux", "other"):
            assert f"{sentiment}/{topic}" in assets["playbooks"]


def test_generate_replies_marks_negatives_for_review():
    out = gen.generate_replies(sample_df(), client=get_client(force_offline=True), use_tracking=False)
    assert out.reply.notna().all()
    assert out.loc[out.review_id == "1", "reply_status"].iloc[0] == "needs_review"
    assert out.loc[out.review_id == "2", "reply_status"].iloc[0] == "auto_send"


def test_generate_replies_with_judge_adds_scores():
    out = gen.generate_replies(sample_df(), client=get_client(force_offline=True), use_tracking=False,
                               judge=True, judge_client=get_client(force_offline=True))
    assert "judge_empathy" in out.columns
    assert out["judge_empathy"].between(1, 5).all()


def test_judge_acceptable_rule():
    good = {"empathy": 4, "specificity": 4, "correctness": 5, "tone": 4,
            "promises_outcome": False, "invents_facts": False, "wrong_language": False}
    assert jd.acceptable(good) is True
    assert jd.acceptable({**good, "promises_outcome": True}) is False
    assert jd.acceptable({**good, "correctness": 2}) is False


def test_evaluate_replies_aggregates():
    out = gen.generate_replies(sample_df(), client=get_client(force_offline=True), use_tracking=False,
                               judge=True, judge_client=get_client(force_offline=True))
    report = jd.evaluate_replies(out)
    assert report["n"] == 3 and "mean_scores" in report
