"""Check ``prompts/issue_cluster_v1.txt``: does the LLM put negative reviews into
the same issue category that the embedding + k-means clustering found?

n8n Cloud cannot run embeddings, so the n8n workflow assigns categories with the
LLM instead; this script measures how well that proxy agrees with the clustering.

    python scripts/eval_issue_assignment.py --n 100
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src import config  # noqa: E402
from src.llmops import tracking  # noqa: E402
from src.llmops.llm_client import get_client, parse_json, text_of  # noqa: E402

PROC = ROOT / "data" / "processed"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=100)
    ap.add_argument("--live", action="store_true")
    args = ap.parse_args()

    clusters_path = PROC / "analyzed_reviews.csv"
    if not clusters_path.exists():
        sys.exit("run scripts/run_pipeline.py first (needs analyzed_reviews.csv with cluster_id)")
    df = pd.read_csv(clusters_path)
    df = df[(df.sentiment == "negative") & df.cluster_id.notna()].reset_index(drop=True)
    if df.empty:
        sys.exit("no clustered negative reviews found")
    df = df.sample(min(args.n, len(df)), random_state=1).reset_index(drop=True)

    system = (config.PROMPTS_DIR / "issue_cluster_v1.txt").read_text(encoding="utf-8")
    tax = json.loads((config.PROMPTS_DIR / "issue_taxonomy_v1.json").read_text(encoding="utf-8"))
    client = tracking.TrackedClient(get_client(force_offline=False if args.live else None), "issue_cluster", "issue_cluster_v1")

    rows = []
    for i in range(0, len(df), 10):
        chunk = df.iloc[i:i + 10]
        payload = [{"id": r.review_id, "text": (r.get("translated_text") or r.review_text)[:700]}
                   for r in chunk.itertuples()]
        resp = client.messages.create(model=config.LLM_MODEL, max_tokens=1500, system=system,
                                      messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}])
        got = {a["id"]: a for a in parse_json(text_of(resp))["assignments"]}
        for r in chunk.itertuples():
            a = got.get(r.review_id)
            rows.append({"review_id": r.review_id, "kmeans": r.cluster_id,
                         "llm": a["category"] if a else None, "issue": a["issue"] if a else None,
                         "text": r.review_text})

    out = pd.DataFrame(rows)
    ok = out.dropna(subset=["llm"])
    if ok.empty:
        sys.exit("no assignments produced")
    agree = (ok.kmeans.astype(int) == ok.llm.astype(int)).mean()
    print(f"{len(ok)} of {len(df)} assigned; exact agreement with the k-means cluster: {agree:.1%}; "
          f"'none fits' (-1): {(ok.llm.astype(int) == -1).mean():.1%}")
    print("spread of LLM categories:", dict(Counter(ok.llm.astype(int)).most_common()))
    print("\nexamples where they differ:")
    for r in ok[ok.kmeans.astype(int) != ok.llm.astype(int)].head(6).itertuples():
        print(f"  kmeans={tax.get(str(int(r.kmeans)), '?')[:34]!r:38} "
              f"llm={tax.get(str(int(r.llm)), 'none')[:34]!r:38} issue={r.issue!r}")
    out.to_csv(PROC / "issue_assignment_eval.csv", index=False, encoding="utf-8")


if __name__ == "__main__":
    main()
