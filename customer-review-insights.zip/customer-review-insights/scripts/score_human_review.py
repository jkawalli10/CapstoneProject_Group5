"""Score the human-review queue produced by ``scripts/eval_responses.py``.

A reviewer fills the ``human_accept`` column (yes/no, or 1/0) and optionally a
comment. This script computes the human-acceptance rate against the proposal's
80% target, broken down by sentiment and language.

    python scripts/score_human_review.py data/processed/review_queue.csv
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src import config  # noqa: E402

YES = {"yes", "y", "1", "true", "accept", "accepted", "ok"}


def to_bool(v) -> bool | None:
    if pd.isna(v) or str(v).strip() == "":
        return None
    return str(v).strip().lower() in YES


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default="data/processed/review_queue.csv")
    args = ap.parse_args()
    path = ROOT / args.path
    if not path.exists():
        sys.exit(f"no such file: {path} (run scripts/eval_responses.py first)")

    df = pd.read_csv(path)
    if "human_accept" not in df.columns:
        sys.exit("the file has no 'human_accept' column to score")
    df["accepted"] = df["human_accept"].map(to_bool)
    scored = df.dropna(subset=["accepted"])
    if scored.empty:
        sys.exit("no rows scored yet: fill the 'human_accept' column first")

    rate = scored["accepted"].mean()
    print(f"human acceptance: {rate:.1%} over {len(scored)} scored replies "
          f"(target {config.TARGET_HUMAN_ACCEPTANCE:.0%}) "
          f"{'PASS' if rate >= config.TARGET_HUMAN_ACCEPTANCE else 'below target'}")
    for col in ("sentiment", "detected_language"):
        if col in scored.columns:
            print(f"\nby {col}:")
            print(scored.groupby(col)["accepted"].agg(["mean", "count"]).round(3).to_string())


if __name__ == "__main__":
    main()
