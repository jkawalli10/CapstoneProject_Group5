"""Upload ``space_build/`` to a Hugging Face Space and put it on the free CPU tier.

    python scripts/build_space.py
    python scripts/deploy_space.py

Needs ``HF_TOKEN`` (a write token) in ``.env``. The Anthropic key is NOT sent by
this script: add it yourself as a Space secret named ``ANTHROPIC_API_KEY`` in the
Space settings (or leave it out to run the demo in offline mode).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

try:
    from dotenv import load_dotenv

    load_dotenv(ROOT / ".env")
except Exception:
    pass


def main() -> None:
    from huggingface_hub import HfApi

    repo = os.getenv("HF_SPACE_ID", "your-username/review-insights-demo")
    bundle = ROOT / "space_build"
    token = os.getenv("HF_TOKEN")
    if not token:
        sys.exit("HF_TOKEN is not set in .env (create a write token at https://huggingface.co/settings/tokens)")
    if not (bundle / "app.py").exists():
        sys.exit("space_build/ is missing: run python scripts/build_space.py first")

    api = HfApi(token=token)
    print("signed in as:", api.whoami()["name"])
    api.upload_folder(folder_path=str(bundle), repo_id=repo, repo_type="space",
                      commit_message="Deploy demo app",
                      ignore_patterns=["__pycache__", "*.pyc", "data/processed"])
    try:
        api.request_space_hardware(repo_id=repo, hardware="cpu-basic")  # free tier
    except Exception as e:  # the Space may already be on it
        print("hardware request:", type(e).__name__, str(e)[:120])
    print(f"done: https://huggingface.co/spaces/{repo}")


if __name__ == "__main__":
    main()
