"""Evaluate sentiment classification on the MARC sample and compare the three
models the proposal asks about: TF-IDF baseline, LLM few-shot, and the stacker.

Ground truth comes from star ratings (1-2 -> negative, 3 -> neutral, 4-5 -> positive).
The sample is split per language and star into a DEV part (tune prompts here) and a
TEST part (final reported numbers).

    python scripts/eval_sentiment.py --per-star 20            # offline, free
    python scripts/eval_sentiment.py --per-star 40 --live     # real Claude calls

Writes ``data/processed/sentiment_eval.csv`` (per-language table) and prints the
baseline-vs-LLM-vs-stacker comparison.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.analysis import sentiment as sa  # noqa: E402
from src.ingestion import loader  # noqa: E402
from src.llmops.llm_client import get_client  # noqa: E402

PROC = ROOT / "data" / "processed"


def load_sample(per_star: int, split: str = "test") -> pd.DataFrame:
    df = loader.load_marc_all(per_star=per_star, split=split)
    if df.empty:
        from scripts.generate_synthetic_reviews import generate

        df = generate(n_per_lang=per_star * 5)
    df = sa.add_truth(df)
    # deterministic dev/test split: within each language+star the first half is dev
    df["_pos"] = df.groupby(["detected_language", "rating"]).cumcount()
    df["split"] = (df["_pos"] % 2 == 0).map({True: "dev", False: "test"})
    return df


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-star", type=int, default=20)
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--split", default="test", choices=["dev", "test", "all"])
    args = ap.parse_args()

    client = get_client(force_offline=False if args.live else None)
    print(f"LLM mode: {'offline (heuristics)' if client.offline else 'live Claude'}")

    df = load_sample(args.per_star)
    if args.split != "all":
        df = df[df.split == args.split].reset_index(drop=True)
    print(f"evaluating on {len(df)} reviews across {df.detected_language.nunique()} languages")

    # 1) TF-IDF baseline -- trained on the dev half, evaluated on test
    dev = load_sample(args.per_star)
    dev = dev[dev.split == "dev"]
    pipe, text_col = sa.train_baseline(dev)
    df = sa.predict_baseline(pipe, df, text_col)

    # 2) LLM few-shot
    df = sa.classify_llm(df, client=client)

    # 3) Stacker over baseline probs + LLM features (fit on dev predictions)
    dev = sa.predict_baseline(pipe, dev, text_col)
    dev = sa.classify_llm(dev, client=client)
    dev["truth"] = dev["rating"].apply(lambda r: sa.stars_to_label(int(r)))
    stacker = sa.train_stacker(dev)
    df = sa.predict_stacker(stacker, df)

    print("\n== model comparison (accuracy / macro-F1) ==")
    print(sa.compare_models(df).to_string(index=False))

    print("\n== per-language, stacked model ==")
    table = sa.evaluate_by_language(df, "stacked_sentiment")
    print(table.to_string(index=False))
    PROC.mkdir(parents=True, exist_ok=True)
    table.to_csv(PROC / "sentiment_eval.csv", index=False, encoding="utf-8")
    df.to_csv(PROC / "sentiment_predictions.csv", index=False, encoding="utf-8")

    best = sa.evaluate(df["stacked_sentiment"], df["truth"])["accuracy"]
    print(f"\ntarget accuracy {sa.config.TARGET_SENTIMENT_ACCURACY:.0%}, stacked model {best:.1%} "
          f"({'PASS' if best >= sa.config.TARGET_SENTIMENT_ACCURACY else 'below target'})")


if __name__ == "__main__":
    main()
