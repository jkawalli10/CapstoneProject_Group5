"""End-to-end pipeline: ingest -> translate -> classify -> issues -> cluster ->
trends -> draft replies -> judge.

Runs fully offline (deterministic heuristics) when no ``ANTHROPIC_API_KEY`` is set,
so it doubles as a smoke test and as the reproducible "golden run" for the report.

    python scripts/run_pipeline.py --per-star 8            # quick offline run
    python scripts/run_pipeline.py --per-star 40 --live    # real Claude calls

Outputs land in ``data/processed/``:
  * ``unified_reviews.csv``      -- the normalised input
  * ``analyzed_reviews.csv``     -- sentiment/topic/issue/cluster/reply per review
  * ``cluster_summary.csv``      -- cluster sizes, language mix, topic purity
  * ``trend_spikes.csv``         -- flagged (issue, week) spikes
  * ``reply_eval.json``          -- judge rubric + acceptance summary
  * ``llm_calls.jsonl``          -- the LLMOps call log (tokens, cost, latency)
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src import config  # noqa: E402
from src.analysis import clustering as cl  # noqa: E402
from src.analysis import sentiment as sa  # noqa: E402
from src.analysis import trends as tr  # noqa: E402
from src.ingestion import loader  # noqa: E402
from src.llmops.llm_client import get_client  # noqa: E402
from src.response import generate as gen  # noqa: E402
from src.response import judge as jd  # noqa: E402
from src.translation import translate as tl  # noqa: E402

PROC = config.PROCESSED_DIR


def _log(msg: str) -> None:
    print(f"[pipeline] {msg}", flush=True)


def ingest(per_star: int) -> pd.DataFrame:
    _log(f"ingesting MARC sample ({per_star} per star, {len(config.LANGUAGES)} languages)")
    df = loader.load_marc_all(per_star=per_star)
    if df.empty:
        _log("no MARC rows found; generating synthetic reviews instead")
        from scripts.generate_synthetic_reviews import generate

        df = generate(n_per_lang=per_star * 5)
    df.to_csv(PROC / "unified_reviews.csv", index=False, encoding="utf-8")
    _log(f"unified schema: {len(df)} rows, languages {sorted(df.detected_language.dropna().unique())}")
    return df


def translate(df: pd.DataFrame, client) -> pd.DataFrame:
    _log("translating non-English reviews to English")
    out = tl.translate_reviews(df, client=client)
    _log(f"translation: {tl.summary(out)}")
    return out


def classify(df: pd.DataFrame, client) -> pd.DataFrame:
    _log("classifying sentiment + topic (LLM)")
    out = sa.classify_llm(df, client=client)
    out = sa.add_truth(out)
    _log(f"sentiment mix: {out.sentiment.value_counts().to_dict()}")
    return out


def issues(df: pd.DataFrame, client) -> pd.DataFrame:
    """Add a short English issue phrase to every negative review."""
    _log("extracting issue phrases for negative reviews")
    neg = df[df.sentiment == "negative"].copy()
    if neg.empty:
        df["issue"] = None
        return df
    from src.llmops import tracking
    from src.llmops.llm_client import parse_json, text_of

    system = (config.PROMPTS_DIR / "issue_v1.txt").read_text(encoding="utf-8")
    tracked = tracking.TrackedClient(client, "issue", "issue_v1")
    phrases = {}
    rows = neg.to_dict("records")
    for i in range(0, len(rows), 10):
        chunk = rows[i:i + 10]
        payload = [{"id": r["review_id"], "text": (r.get("translated_text") or r["review_text"])[:700]}
                   for r in chunk]
        try:
            resp = tracked.messages.create(model=config.LLM_MODEL, max_tokens=1500, system=system,
                                           messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}])
            for it in parse_json(text_of(resp)).get("issues", []):
                phrases[it["id"]] = it["issue"]
        except Exception as exc:  # pragma: no cover
            _log(f"issue batch failed: {str(exc)[:120]}")
    df["issue"] = df["review_id"].map(phrases)
    _log(f"issues extracted for {df['issue'].notna().sum()} reviews")
    return df


def cluster(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    _log("clustering negative reviews by issue")
    neg = df[df.sentiment == "negative"].copy()
    if len(neg) < 10:
        df["cluster_id"] = -1
        return df, pd.DataFrame()
    text_col = "translated_text" if neg["translated_text"].notna().any() else "review_text"
    neg, sil = cl.cluster_reviews(neg, text_col=text_col, method="kmeans", backend="auto")
    labels = cl.label_clusters(neg)
    neg["cluster_label"] = neg["cluster_id"].map(labels)
    summary = cl.summarize(neg)
    summary.to_csv(PROC / "cluster_summary.csv", index=False, encoding="utf-8")
    if not sil.empty:
        sil.to_csv(PROC / "cluster_silhouette.csv", index=False, encoding="utf-8")
    merged = df.merge(neg[["review_id", "cluster_id", "cluster_label"]], on="review_id", how="left")
    _log(f"clusters: {summary.set_index('cluster')['size'].to_dict() if not summary.empty else {}}")
    return merged, summary


def trends(df: pd.DataFrame, summary: pd.DataFrame) -> pd.DataFrame:
    """Plant spikes on a synthetic timeline and validate the detector."""
    _log("validating trend detection against planted spikes")
    neg = df[df.sentiment == "negative"].copy()
    if neg.empty or "cluster_id" not in neg.columns:
        return pd.DataFrame()
    neg = neg[neg.cluster_id.notna()]
    if neg.cluster_id.nunique() < 2:
        return pd.DataFrame()
    sizes = neg.cluster_id.value_counts()
    picks = list(sizes.index[:3])
    spikes = [{"cluster": int(picks[0]), "week": 7, "factor": 5.0},
              {"cluster": int(picks[1]), "week": 9, "factor": 4.0},
              {"cluster": int(picks[2]), "week": 10, "factor": 3.0}]
    # The default ``min_count=8`` assumes production volume (1,000+ reviews/day).
    # On a small sample we scale it down so planted spikes remain detectable.
    min_count = max(3, int(round(0.4 * sizes.max() / 12)))
    results = {"flag_z": [], "flag_ewma": []}
    for seed in range(100):
        week = tr.assign_timeline(neg, "cluster_id", spikes, seed=seed)
        flags = tr.detect_spikes(tr.weekly_counts(neg, week, "cluster_id"), min_count=min_count)
        for rule in results:
            results[rule].append(tr.evaluate(flags, spikes, rule))
    rows = []
    for rule, lst in results.items():
        d = pd.DataFrame(lst)
        rows.append({"rule": rule, "precision": round(d.precision.mean(), 3), "recall": round(d.recall.mean(), 3),
                     "precision_at_k": round(d.precision_at_k.mean(), 3), "false_alarms": round(d.fp.mean(), 2)})
    out = pd.DataFrame(rows)
    out.to_csv(PROC / "trend_spikes.csv", index=False, encoding="utf-8")
    week = tr.assign_timeline(neg, "cluster_id", spikes, seed=0)
    flags = tr.detect_spikes(tr.weekly_counts(neg, week, "cluster_id"), min_count=min_count)
    tr.top_spikes(flags).to_csv(PROC / "trend_example_seed0.csv", index=False, encoding="utf-8")
    _log("trend detection:\n" + out.to_string(index=False))
    return out


def replies(df: pd.DataFrame, client, do_judge: bool) -> dict:
    _log("drafting replies" + (" and judging them" if do_judge else ""))
    sample = df.sample(min(48, len(df)), random_state=0).copy()
    sample["customer_name"] = None
    out = gen.generate_replies(sample, client=client, judge=do_judge, judge_client=client)
    out.to_csv(PROC / "reply_eval.csv", index=False, encoding="utf-8")
    report = gen.summary(out)
    if do_judge and f"judge_empathy" in out.columns:
        report["judge"] = jd.evaluate_replies(out)
    (PROC / "reply_eval.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    _log(f"replies: {report}")
    return report


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-star", type=int, default=8, help="reviews per star rating per language")
    ap.add_argument("--live", action="store_true", help="force real Claude calls (needs ANTHROPIC_API_KEY)")
    ap.add_argument("--no-judge", action="store_true", help="skip the LLM judge")
    args = ap.parse_args()

    PROC.mkdir(parents=True, exist_ok=True)
    client = get_client(force_offline=False if args.live else None)
    _log(f"LLM mode: {'offline (heuristics)' if client.offline else 'live Claude'}")

    df = ingest(args.per_star)
    df = translate(df, client)
    df = classify(df, client)
    df = issues(df, client)
    df, summary = cluster(df)
    trends(df, summary)
    df.to_csv(PROC / "analyzed_reviews.csv", index=False, encoding="utf-8")
    replies(df, client, do_judge=not args.no_judge)
    _log(f"done. artifacts in {PROC}")


if __name__ == "__main__":
    main()
