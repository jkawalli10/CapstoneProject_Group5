"""Smoke-test the Claude key with one tiny call. Reads the key from ``.env``.

    python scripts/check_keys.py

Prints the model, a one-word reply and the token usage. Exits non-zero when no
key is configured (the rest of the project still runs offline in that case).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv

    load_dotenv(ROOT / ".env")
except Exception:
    pass

PROMPT = "Reply with exactly one word: the sentiment (positive/negative/neutral) of: 'Arrived late and broken.'"


def main() -> None:
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        print("CLAUDE: no ANTHROPIC_API_KEY set -- the project will run in offline mode")
        sys.exit(1)
    import anthropic

    model = os.getenv("CLAUDE_MODEL", "claude-haiku-4-5")
    r = anthropic.Anthropic(api_key=key).messages.create(
        model=model, max_tokens=16, messages=[{"role": "user", "content": PROMPT}])
    print(f"CLAUDE OK  model={model}  reply={r.content[0].text!r}  "
          f"tokens in/out={r.usage.input_tokens}/{r.usage.output_tokens}")


if __name__ == "__main__":
    main()
