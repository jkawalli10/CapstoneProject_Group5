"""Focused stacker experiment: combine the LLM's sentiment / confidence / star
estimate with the TF-IDF baseline's per-class probabilities, and report the full
comparison table (3-way accuracy, macro-F1, neutral recall, binary accuracy).

    python scripts/stack_sentiment.py --per-star 20            # offline
    python scripts/stack_sentiment.py --per-star 40 --live     # real Claude

This is a thin, readable wrapper over :mod:`src.analysis.sentiment` so the
stacker numbers in the report can be reproduced with one command.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.analysis import sentiment as sa  # noqa: E402
from src.ingestion import loader  # noqa: E402
from src.llmops.llm_client import get_client  # noqa: E402

PROC = ROOT / "data" / "processed"


def score(y_true: pd.Series, y_pred: pd.Series) -> dict:
    nn = y_true != "neutral"
    binary_pred = y_pred[nn].where(y_pred[nn] != "neutral", "x")
    return {
        "3-way acc": round(accuracy_score(y_true, y_pred), 3),
        "macroF1": round(f1_score(y_true, y_pred, average="macro"), 3),
        "neutral recall": round(float(((y_pred == "neutral") & (y_true == "neutral")).sum()
                                      / max((y_true == "neutral").sum(), 1)), 3),
        "binary acc": round(accuracy_score(y_true[nn], binary_pred), 3),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-star", type=int, default=20)
    ap.add_argument("--live", action="store_true")
    args = ap.parse_args()

    client = get_client(force_offline=False if args.live else None)
    print(f"LLM mode: {'offline (heuristics)' if client.offline else 'live Claude'}")

    df = loader.load_marc_all(per_star=args.per_star)
    if df.empty:
        from scripts.generate_synthetic_reviews import generate

        df = generate(n_per_lang=args.per_star * 5)
    df = sa.add_truth(df)
    df["_pos"] = df.groupby(["detected_language", "rating"]).cumcount()
    train = df[df["_pos"] % 2 == 0].reset_index(drop=True)
    test = df[df["_pos"] % 2 == 1].reset_index(drop=True)

    pipe, text_col = sa.train_baseline(train)
    train = sa.predict_baseline(pipe, train, text_col)
    test = sa.predict_baseline(pipe, test, text_col)
    train = sa.classify_llm(train, client=client)
    test = sa.classify_llm(test, client=client)

    stacker = sa.train_stacker(train)
    test = sa.predict_stacker(stacker, test)

    rows = [
        {"model": "baseline TF-IDF", **score(test.truth, test.baseline_sentiment)},
        {"model": "LLM label", **score(test.truth, test.sentiment)},
        {"model": "LLM star estimate -> label",
         **score(test.truth, test.stars_estimate.fillna(3).round().clip(1, 5).astype(int).map(sa.stars_to_label))},
        {"model": "stacker (LLM + baseline)", **score(test.truth, test.stacked_sentiment)},
    ]
    out = pd.DataFrame(rows)
    print("\n" + out.to_string(index=False))
    PROC.mkdir(parents=True, exist_ok=True)
    out.to_csv(PROC / "stacker_results.csv", index=False, encoding="utf-8")
    print(f"\nsaved -> {PROC / 'stacker_results.csv'}")


if __name__ == "__main__":
    main()
