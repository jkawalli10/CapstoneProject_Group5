"""Stage 5: draft replies for a stratified set of reviews, score them with the LLM
judge, and build the human-review queue.

    python scripts/eval_responses.py --n 2            # offline, free
    python scripts/eval_responses.py --n 2 --live     # real Claude calls

Outputs:
  * ``data/processed/response_eval.csv``  -- replies + judge scores
  * ``data/processed/review_queue.csv``   -- rows with empty ``human_accept`` /
    ``human_comment`` columns for the team to fill; score with
    ``scripts/score_human_review.py``.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src import config  # noqa: E402
from src.llmops.llm_client import get_client  # noqa: E402
from src.response import generate as gen  # noqa: E402
from src.response import judge as jd  # noqa: E402

PROC = ROOT / "data" / "processed"

NAMES = {  # synthetic first names so personalisation can be tested (MARC has none)
    "en": ["Emma", "Daniel", "Priya", "Marcus"], "de": ["Anna", "Lukas", "Sabine", "Jonas"],
    "es": ["Lucia", "Carlos", "Marta", "Diego"], "fr": ["Camille", "Louis", "Claire", "Hugo"],
    "ja": ["田中", "佐藤", "鈴木", "伊藤"], "zh": ["王女士", "李先生", "张女士", "陈先生"],
}


def build_eval_set(n: int) -> pd.DataFrame:
    path = PROC / "analyzed_reviews.csv"
    if not path.exists():
        sys.exit("run scripts/run_pipeline.py first (needs analyzed_reviews.csv)")
    df = pd.read_csv(path)
    parts = []
    for lang in config.LANGUAGES:
        for sent, k in (("negative", 2 * n), ("neutral", n), ("positive", n)):
            pool = df[(df.detected_language == lang) & (df.sentiment == sent)]
            if len(pool):
                parts.append(pool.sample(min(k, len(pool)), random_state=0))
    out = pd.concat(parts).reset_index(drop=True)
    out["customer_name"] = [NAMES.get(l, NAMES["en"])[i % 4] for i, l in enumerate(out.detected_language)]
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=2, help="reviews per language and sentiment group")
    ap.add_argument("--live", action="store_true")
    args = ap.parse_args()

    client = get_client(force_offline=False if args.live else None)
    print(f"LLM mode: {'offline (heuristics)' if client.offline else 'live Claude'}")

    df = build_eval_set(args.n)
    print(f"{len(df)} reviews: {df.sentiment.value_counts().to_dict()}; "
          f"languages: {df.detected_language.value_counts().to_dict()}")

    out = gen.generate_replies(df, client=client, judge=True, judge_client=client)
    out.to_csv(PROC / "response_eval.csv", index=False, encoding="utf-8")

    print("\n== judge scores (1-5) ==")
    if "judge_empathy" in out.columns:
        print(out[jd.DIMENSIONS].astype(float).mean().round(2).to_dict())
        print("guardrail flags:", {f: int(out[f"judge_{f}"].sum()) for f in jd.FLAGS if f"judge_{f}" in out.columns})
        report = jd.evaluate_replies(out)
        print(f"judge-acceptable: {report.get('acceptance_rate')} (target {config.TARGET_HUMAN_ACCEPTANCE})")
        print("\nby sentiment:")
        print(out.groupby("sentiment")[jd.DIMENSIONS].mean().round(2).to_string())

    queue = out[["review_id", "detected_language", "sentiment", "topic", "issue", "review_text", "reply", "reply_status"]].copy()
    queue["human_accept"] = ""
    queue["human_comment"] = ""
    queue.to_csv(PROC / "review_queue.csv", index=False, encoding="utf-8")
    print(f"\nwrote {len(queue)} rows to review_queue.csv for human scoring")


if __name__ == "__main__":
    main()
