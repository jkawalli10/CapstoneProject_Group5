"""Generate synthetic multilingual reviews in the unified schema.

Used as a zero-dependency fallback when the MARC corpus cannot be downloaded
(no network / no ``datasets`` install) so the whole pipeline still runs. The
templates cover each language and sentiment with realistic phrasing and product
categories, and a deterministic RNG keeps runs reproducible.

    python scripts/generate_synthetic_reviews.py --per-lang 40 --out data/samples/synthetic_reviews.csv
"""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

LANGS = ["en", "de", "es", "fr", "ja", "zh"]
CATEGORIES = ["electronics", "home", "book", "toy", "apparel", "kitchen"]

# (sentiment, stars) -> template per language. {cat} is filled with the category.
TEMPLATES = {
    "en": {
        "positive": ["Excellent {cat}, works perfectly and arrived quickly.", "Great quality {cat}, very happy with it.", "Love this {cat}, exactly as described and easy to use."],
        "neutral": ["The {cat} is okay, does the job but nothing special.", "Average {cat}, arrived fine but a bit pricey.", "It works, though the {cat} feels a little cheap."],
        "negative": ["The {cat} arrived late and was damaged.", "Poor quality {cat}, it stopped working after two weeks.", "The {cat} does not work as described, very disappointed."],
    },
    "de": {
        "positive": ["Ausgezeichnetes {cat}, funktioniert einwandfrei.", "Sehr gute Qualität, bin sehr zufrieden.", "Tolles {cat}, genau wie beschrieben."],
        "neutral": ["Das {cat} ist okay, macht seinen Job.", "Durchschnittliches {cat}, etwas teuer.", "Es funktioniert, wirkt aber etwas billig."],
        "negative": ["Das {cat} kam zu spät und war beschädigt.", "Schlechte Qualität, nach zwei Wochen defekt.", "Das {cat} funktioniert nicht wie beschrieben."],
    },
    "es": {
        "positive": ["Excelente {cat}, funciona perfectamente.", "Muy buena calidad, estoy muy contento.", "Me encanta este {cat}, tal como se describe."],
        "neutral": ["El {cat} está bien, cumple su función.", "Producto promedio, un poco caro.", "Funciona, aunque parece barato."],
        "negative": ["El {cat} llegó tarde y dañado.", "Mala calidad, dejó de funcionar en dos semanas.", "El {cat} no funciona como se describe."],
    },
    "fr": {
        "positive": ["Excellent {cat}, fonctionne parfaitement.", "Très bonne qualité, très satisfait.", "J'adore ce {cat}, conforme à la description."],
        "neutral": ["Le {cat} est correct, fait le travail.", "Produit moyen, un peu cher.", "Ça marche, mais semble bon marché."],
        "negative": ["Le {cat} est arrivé en retard et endommagé.", "Mauvaise qualité, en panne après deux semaines.", "Le {cat} ne fonctionne pas comme décrit."],
    },
    "ja": {
        "positive": ["素晴らしい{cat}、完璧に動作します。", "品質が良くてとても満足しています。", "説明通りで使いやすい{cat}です。"],
        "neutral": ["{cat}はまあまあ、普通に使えます。", "平均的な{cat}、少し高いです。", "動きますが、少し安っぽいです。"],
        "negative": ["{cat}が遅れて届き、破損していました。", "品質が悪く、二週間で壊れました。", "{cat}は説明通りに動作しません。"],
    },
    "zh": {
        "positive": ["非常好的{cat}，运行完美。", "质量很好，非常满意。", "很喜欢这个{cat}，与描述一致。"],
        "neutral": ["{cat}还可以，能用。", "普通的{cat}，有点贵。", "能用，但感觉有点廉价。"],
        "negative": ["{cat}到货晚了而且损坏了。", "质量差，两周就坏了。", "{cat}不像描述的那样工作。"],
    },
}
STAR_BY_SENT = {"positive": [4, 5], "neutral": [3], "negative": [1, 2]}


def generate(n_per_lang: int = 40, seed: int = 42) -> pd.DataFrame:
    import numpy as np

    rng = np.random.default_rng(seed)
    rows = []
    for lang in LANGS:
        for i in range(n_per_lang):
            sentiment = rng.choice(["positive", "neutral", "negative"])
            cat = rng.choice(CATEGORIES)
            template = rng.choice(TEMPLATES[lang][sentiment])
            text = template.format(cat=cat)
            stars = int(rng.choice(STAR_BY_SENT[sentiment]))
            rows.append({
                "review_id": f"syn-{lang}-{i:04d}",
                "source": "synthetic",
                "product_category": cat,
                "rating": stars,
                "review_text": text,
                "detected_language": lang,
                "translated_text": None,
                "review_date": None,
            })
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-lang", type=int, default=40)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="data/samples/synthetic_reviews.csv")
    args = ap.parse_args()
    df = generate(args.per_lang, args.seed)
    path = Path(__file__).resolve().parents[1] / args.out
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8")
    print(f"wrote {len(df)} synthetic reviews -> {path}")
    print(df.groupby(["detected_language", "rating"]).size().unstack(fill_value=0))


if __name__ == "__main__":
    main()
