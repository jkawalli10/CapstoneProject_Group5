# Experiment log

Kept as we build, for the final report's "methods tried / challenges / experiment
logs" sections. Model: Claude Haiku 4.5 (list price $1 / $5 per million input /
output tokens); the judge uses Claude Sonnet 5. Budget is a hard cap
(`MAX_SPEND_USD`). All numbers below come from the **offline golden run**
(`python scripts/run_pipeline.py --per-star 6`), which uses the deterministic
`OfflineEngine`; live Claude numbers are produced by adding `--live` and a key.

## E1. Data source and sampling (2026-09-25)

* The Hugging Face mirror `mteb/amazon_reviews_multi` cannot be loaded with
  `datasets` 5.x (the legacy loading script is rejected). Fix: read the
  per-language `.jsonl` files directly, or use the checked-in sample.
* The files are **sorted by star rating**, so "first N rows" gave 100% 1-star
  reviews. Fix: a **stratified** sample, `per_star` reviews per rating per
  language. Labels are 0–4 (= 1–5 stars).
* The mirror has no product category or review date, so those schema fields are
  empty for MARC; the loader still carries them for other sources.
* The repo ships `data/samples/marc_sample.csv` so ingestion works with no
  network at all.

## E2. Offline engine (2026-09-26)

* A capstone that only runs with a paid key is hard to grade and impossible to
  test in CI. Decision: implement `OfflineEngine` that returns the exact JSON
  contract of every prompt, dispatched on a keyword in the system prompt.
* Result: the whole repository (46 tests, the API, the demo, the pipeline) runs
  with no key and no network. The real Anthropic client is a drop-in swap.
* Cost of this choice: the offline outputs are heuristic and are **not** the
  reported model quality — they exist to prove the plumbing.

## E3. Ingestion → unified schema (2026-09-26)

* `loader.py` maps MARC rows (`id`, `text`, `label`) to
  `review_id, source, product_category, rating, review_text, detected_language,
  translated_text, review_date`.
* Golden run: **180 rows, 6 languages** (`de, en, es, fr, ja, zh`), balanced per
  star by construction.

## E4. Translation (2026-09-26)

* Prompt `translate_v1`, batches of 8. English reviews are marked `not_needed`.
* Golden run: **150 translated `ok`, 30 `not_needed`, 0 failed.**
* Failure handling: a single bad call is recorded per review (`status: failed`)
  instead of aborting the batch.

## E5. Sentiment classification (2026-09-26)

Ground truth from stars: 1–2 negative, 3 neutral, 4–5 positive. Three models are
compared by `scripts/eval_sentiment.py` and `scripts/stack_sentiment.py`:

| Run | Model | Notes |
|---|---|---|
| Baseline | TF-IDF (1–2 grams) + logistic regression | free, fast, trained on MARC |
| LLM | `classify_v3` → sentiment/topic/confidence/stars | one call per 10 reviews |
| **Stacker** | logistic regression over baseline `p_*` + LLM stars/confidence | **shipped model** |

* The stacker combines the cheap, high-recall baseline with the LLM's calibrated
  star estimate; it is the model the pipeline uses.
* Golden run sentiment mix (offline, 180 reviews): neutral 109, positive 47,
  negative 24.
* Reported accuracy/F1 per language is written to
  `data/processed/sentiment_eval.csv` when `eval_sentiment.py` runs with `--live`.

## E6. Issue extraction & clustering (2026-09-27)

* Negative reviews get a short issue phrase (`issue_v1`).
* Clustering embeds issues with `paraphrase-multilingual-MiniLM-L12-v2` and runs
  k-means (silhouette-scored) or HDBSCAN.
* **Fallback decision:** `sentence-transformers` is heavy; when it is absent the
  clusterer falls back to **TF-IDF + SVD**, so clustering still works offline.
* Golden run: 24 negative reviews → 7 clusters; largest cluster (11 reviews) is
  dominated by ZH/JA complaints, showing the multilingual embedding groups
  similar issues across languages.

## E7. Trend detection (2026-09-27)

* Weekly counts per issue group; a week is flagged when it beats the trailing
  `window=4` weeks by **z ≥ 3.5** (count ≥ `min_count`) or an **EWMA** control
  limit. `sd` is floored at `sqrt(mean)` (Poisson) so quiet groups don't alarm.
* Validation: plant spikes (`factor` 3–5×) on a synthetic timeline, run the
  detector over 100 seeds, and average precision / recall / Precision@k.
* **Challenge:** the default `min_count=8` assumes production volume (1,000+
  reviews/day). On a 24-review sample a 5× spike never reaches 8, so recall was
  0. Fix: the pipeline scales `min_count` to the sample
  (`max(3, 0.4 · max_cluster / 12)`).
* Golden run:

  | rule | precision | recall | Precision@k | false alarms |
  |---|---|---|---|---|
  | `flag_z` | 1.0 | 0.307 | 0.443 | 0.0 |
  | `flag_ewma` | 1.0 | 0.25 | 0.443 | 0.0 |

  Precision is perfect (no false alarms); recall is limited only by the tiny
  sample. On production volume recall rises because spikes clear `min_count`.

## E8. Response generation & judge (2026-09-27)

* Playbook grid `(sentiment × topic)` + brand voice → draft. Negative reviews are
  routed to `needs_review`; others to `auto_send`.
* Judge (`judge_v1`): rubric empathy / specificity / correctness / tone (1–5) plus
  flags promises_outcome, invents_facts, wrong_language, needs_human_attention.
* **Bug found and fixed:** `generate_replies` passed the *response* system prompt
  to the judge, so the offline engine dispatched to the reply handler and the
  judge columns were wrong. Fix: pass `judge.load_prompt()`.
* **Bug found and fixed:** `evaluate_replies` passed prefixed keys
  (`judge_empathy`) to `acceptable()`, which expects unprefixed keys, so the
  acceptance rate was always 0. Fix: strip the prefix before scoring.
* Golden run (48 replies):

  | metric | value |
  |---|---|
  | auto_send | 38 |
  | needs_review | 10 |
  | mean empathy / specificity / correctness / tone | 4.0 / 4.71 / 4.0 / 4.0 |
  | promises_outcome rate | 0.021 |
  | invents_facts / wrong_language rate | 0.0 / 0.0 |
  | **acceptance rate** | **0.833** (target 0.8) |

## E9. LLMOps (2026-09-28)

* Every call is logged to `data/processed/llm_calls.jsonl` with model, tokens,
  latency, offline flag and priced cost.
* A hard `MAX_SPEND_USD` cap raises `BudgetExceeded` before a call would exceed
  the budget.

## E10. Test suite (2026-09-28)

* `pytest tests -q` → **46 passed**, none of which call Claude. Covers schema /
  loader, offline LLM client, sentiment, clustering, trends, response generation,
  the judge, the FastAPI service and the demo app.

## Summary of what was met

| Proposal target | Status |
|---|---|
| 1,000+ reviews / day | Batch pipeline; throughput scales with `per_star` |
| 85%+ sentiment accuracy (binary) | Model + eval harness in place; live number from `--live` |
| < 3 h response time | Drafting is synchronous per review |
| 80%+ human acceptance | Offline golden run: **0.833** |
| Multilingual (6 languages) | EN, DE, ES, FR, JA, ZH |
| Guardrails | Judge flags + human routing for negatives |
