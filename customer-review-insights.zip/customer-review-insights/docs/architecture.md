# Architecture

## 1. Design principles

1. **One unified schema.** Every source is normalised once, so every downstream
   stage speaks the same language and can be tested in isolation.
2. **Offline-first.** A deterministic `OfflineEngine` implements the exact JSON
   contract of every prompt, so the pipeline, the API and the demo run with no
   API key and no network. The real Claude client is a drop-in replacement.
3. **Versioned prompts, never inline strings.** Prompt changes are diffable files
   in `prompts/` with a version suffix.
4. **Cost is a first-class constraint.** Every call is priced, logged and capped.
5. **Guardrails before autonomy.** Negative replies never auto-send; the judge
   flags promises, invented facts and wrong-language output.

## 2. Component diagram

```
                        ┌──────────────────────────────────────────────┐
                        │              Ingestion                        │
  MARC / CSV / JSONL ──▶│  src/ingestion/loader.py                      │
                        │  → unified schema (review_id, source, ...)    │
                        └───────────────┬──────────────────────────────┘
                                        │
                        ┌───────────────▼──────────────────────────────┐
                        │              Translation                      │
                        │  src/translation/translate.py                 │
                        │  detect_language → translate_v1 (batches of 8)│
                        └───────────────┬──────────────────────────────┘
                                        │
            ┌───────────────────────────┼───────────────────────────┐
            ▼                           ▼                           ▼
   ┌─────────────────┐       ┌──────────────────┐        ┌──────────────────┐
   │   Sentiment     │       │   Issue extract  │        │   Clustering     │
   │ TF-IDF baseline │       │   issue_v1       │        │ embeddings +     │
   │ + LLM + stacker │       │                  │        │ k-means / HDBSCAN│
   └────────┬────────┘       └────────┬─────────┘        └────────┬─────────┘
            │                         │                           │
            └───────────────┬─────────┴───────────────┬───────────┘
                            ▼                         ▼
                 ┌────────────────────┐    ┌────────────────────────┐
                 │  Trend detection   │    │  Response generation    │
                 │ z-score + EWMA     │    │ playbooks + brand voice │
                 │ planted-spike eval │    │ generate.py             │
                 └─────────┬──────────┘    └───────────┬────────────┘
                           │                           │
                           ▼                           ▼
                 ┌────────────────────┐    ┌────────────────────────┐
                 │  Slack alert       │    │  LLM-as-judge          │
                 │  (n8n workflow 04) │    │  judge.py + guardrails │
                 └────────────────────┘    └────────────────────────┘
```

## 3. LLMOps layer

```
prompt file (versioned) ──▶ LLMClient.create(system=prompt, ...)
                                   │
                     ┌─────────────┴─────────────┐
                     ▼                           ▼
             Anthropic SDK                OfflineEngine
          (real Claude call)         (deterministic JSON)
                     │                           │
                     └─────────────┬─────────────┘
                                   ▼
                        TrackedClient (tracking.py)
                        • prices tokens
                        • enforces MAX_SPEND_USD
                        • appends to llm_calls.jsonl
```

`OfflineEngine.create()` dispatches on a keyword in the system prompt
(`translator`, `customer-experience analyst`, `quality reviewer`, `public replies`,
…) and returns the same JSON shape the prompt asks for. This is what makes the
whole repository runnable and testable without credentials.

## 4. Data flow (offline golden run)

`python scripts/run_pipeline.py --per-star 6`

```
ingest   → 180 rows, 6 languages
translate→ 150 translated, 30 not_needed
classify → sentiment mix (neutral/positive/negative)
issues   → issue phrase per negative review
cluster  → k-means groups (silhouette-scored)
trends   → precision 1.0, recall ~0.3 vs planted spikes
replies  → auto_send / needs_review split
judge    → rubric means + acceptance rate (target 0.8)
```

## 5. Failure handling

| Failure | Behaviour |
|---|---|
| `datasets` / network down | Loader falls back to `data/samples/marc_sample.csv` |
| `sentence-transformers` absent | Clustering falls back to TF-IDF + SVD |
| No `ANTHROPIC_API_KEY` | `OfflineEngine` handles every prompt |
| A single LLM call errors | Recorded per review; batch continues |
| Spend cap reached | `BudgetExceeded` stops the run before overspending |

## 6. Extensibility

* **New source** — add a loader function returning the unified schema.
* **New language** — add the code to `config.LANGUAGES`; translation and
  classification are language-agnostic.
* **New prompt version** — drop a new file in `prompts/` and bump the version
  constant in the calling module.
* **New response channel** — the playbook grid is data, not code.
