# Customer Review Insights & Response Generator

### Final Project Report

**Programme:** TalentSprint — Applied Generative AI & Agentic AI
**Cohort:** 6 · **Group:** 5
**Repository:** `customer-review-insights`

---

## Abstract

Retailers receive thousands of customer reviews every day across many platforms
and languages. Reading them, spotting emerging problems and answering each one is
impossible to do manually at scale. This project delivers an end-to-end,
multilingual pipeline that ingests reviews, translates them to English, classifies
sentiment and topic, extracts and clusters the underlying issues, detects emerging
trends, and drafts on-brand responses with automated guardrails. The system is
built on Anthropic Claude, orchestrated with n8n, exposed through a FastAPI
service and a Gradio demo, and — crucially — runs fully offline with a
deterministic fallback engine so it can be tested and demonstrated without any
API key.

## 1. Problem statement

A multi-platform retailer needs to (a) understand what customers are saying across
languages, (b) catch problems before they escalate, and (c) respond quickly and
consistently. The proposal set four measurable targets: **1,000+ reviews/day**,
**85%+ sentiment accuracy**, **< 3-hour response time**, and **80%+ human
acceptance** of drafted replies, across **six languages**.

## 2. Solution overview

The pipeline has seven stages, each a self-contained module under `src/`:

1. **Ingestion** — normalise any source into one unified schema.
2. **Translation** — detect language, translate non-English reviews to English.
3. **Sentiment + topic** — baseline + LLM + stacker.
4. **Issue extraction** — a short phrase per negative review.
5. **Issue clustering** — multilingual embeddings + k-means/HDBSCAN.
6. **Trend detection** — weekly spike alerts vs a trailing baseline.
7. **Response generation + judge** — playbook drafts with guardrails.

## 3. Data

Primary corpus: the **Multilingual Amazon Reviews Corpus** (MARC, Keung et al.,
2020) — 1.26M reviews in EN, DE, ES, FR, JA, ZH. The loader reads it from the
Hugging Face mirror and takes a **stratified sample per star rating** (the files
are sorted by rating, so naive sampling is biased). A checked-in sample
(`data/samples/marc_sample.csv`) guarantees the pipeline runs with no network.

Ground-truth sentiment is derived from star ratings: 1–2 negative, 3 neutral,
4–5 positive.

## 4. Methods

### 4.1 Unified schema
`review_id, source, product_category, rating, review_text, detected_language,
translated_text, review_date`.

### 4.2 Translation
`translate_v1`, batches of 8, per-review failure recording.

### 4.3 Sentiment
Three models compared: a **TF-IDF + logistic-regression baseline**, an **LLM
classifier** (`classify_v3` returning sentiment/topic/confidence/stars), and a
**stacker** (logistic regression over the baseline probabilities plus the LLM's
star estimate and confidence). The stacker is the shipped model.

### 4.4 Clustering
Multilingual sentence embeddings (`paraphrase-multilingual-MiniLM-L12-v2`) with
k-means (silhouette-scored) or HDBSCAN, falling back to TF-IDF + SVD when the
embedding model is unavailable.

### 4.5 Trend detection
Weekly counts per issue group; a week is flagged when it beats the trailing four
weeks by z-score (z ≥ 3.5, count ≥ min_count) or an EWMA control limit, with the
standard deviation floored at sqrt(mean) (Poisson) to suppress false alarms.
Validated against planted spikes over 100 seeds.

### 4.6 Response generation & judge
A `(sentiment × topic)` playbook grid plus brand voice produces a draft. The
LLM-as-judge scores empathy, specificity, correctness and tone (1–5) and flags
promises, invented facts and wrong-language output. Negatives are routed to human
review.

## 5. Engineering highlights

* **Offline-first design** — `OfflineEngine` implements every prompt's JSON
  contract, so the repo runs with no key and no network.
* **Prompt registry** — versioned prompt files, never inline strings.
* **Cost control** — every call priced, logged to `llm_calls.jsonl`, hard
  `MAX_SPEND_USD` cap.
* **Graceful degradation** — loader, clusterer and LLM client each fall back
  cleanly.
* **46 automated tests**, none of which call Claude.

## 6. Results (offline golden run)

`python scripts/run_pipeline.py --per-star 6`

| Stage | Result |
|---|---|
| Ingestion | 180 rows, 6 languages |
| Translation | 150 translated, 30 not_needed, 0 failed |
| Sentiment | neutral 109, positive 47, negative 24 |
| Clustering | 24 negative reviews → 7 clusters |
| Trend detection | precision 1.0, recall 0.31, Precision@k 0.44, 0 false alarms |
| Responses | 38 auto_send, 10 needs_review |
| Judge | empathy 4.0, specificity 4.71, correctness 4.0, tone 4.0 |
| **Acceptance** | **0.833** (target 0.80) |

The offline engine proves the pipeline; live Claude numbers are produced with
`--live` and a key, and are written to `data/processed/sentiment_eval.csv`.

## 7. Deployment

* **FastAPI** service: `/health`, `/analyze`, `/draft-response`, `/trends`.
* **Gradio** demo: saved examples, live analysis, spike detection.
* **Hugging Face Space**: built by `scripts/build_space.py`, deployed by
  `scripts/deploy_space.py`.
* **n8n** workflows 01–04 for low-code orchestration and Slack alerting.

## 8. Challenges & lessons

1. MARC files are sorted by rating — stratified sampling is essential.
2. `datasets` 5.x rejects the legacy MARC loading script — read JSONL directly.
3. A key-only project is ungradable and untestable — hence the offline engine.
4. Trend thresholds tuned for production volume over-alarm on tiny samples —
   scale `min_count` to the data.
5. Two real bugs (judge prompt passed to the wrong call; prefixed keys to the
   acceptance check) were caught by the test suite and fixed.

## 9. Future work

Live Claude evaluation at full volume; a real product-category join; a feedback
loop that turns human review decisions into training data; and expanding the
playbook grid per brand.

## 10. Conclusion

The project delivers a complete, testable, deployable implementation of the
proposed system. Every proposal target has a mechanism and a measurement, the
pipeline runs end-to-end offline, and the acceptance proxy already exceeds the
80% goal on the golden run.
