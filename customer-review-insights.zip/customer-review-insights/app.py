"""Gradio demo for the Customer Review Insights & Response Generator.

    python app.py            # http://127.0.0.1:7860

Three tabs:

1. **Saved examples** -- browse pre-computed analyses, replies and judge scores.
   No API calls, works with no key, costs nothing.
2. **Live analysis** -- classify a pasted review and draft a reply with Claude.
   Guarded by an optional access code, a per-session call limit and the global
   spend cap.
3. **Spike detection** -- run the trend detector over the sample dashboard data.
   No API calls.

Environment: ``ANTHROPIC_API_KEY`` (live tab only), ``MAX_SPEND_USD`` (default
0.5 here), ``DEMO_ACCESS_CODE`` (optional), ``DEMO_MAX_CALLS`` (default 10).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import pandas as pd

os.environ.setdefault("MAX_SPEND_USD", "0.5")
os.environ.setdefault("RESPONSE_VERSION", "v2")

import gradio as gr  # noqa: E402
from fastapi import HTTPException  # noqa: E402

from src.api import main as api  # noqa: E402
from src.llmops import tracking  # noqa: E402

try:  # ZeroGPU Spaces refuse to start without a @spaces.GPU function
    import spaces

    @spaces.GPU
    def _gpu_placeholder():
        return None
except ImportError:  # running locally or on CPU hardware
    pass

ROOT = Path(__file__).resolve().parent
EXAMPLES = json.loads((ROOT / "data" / "samples" / "demo_examples.json").read_text(encoding="utf-8"))
REVIEWS_CSV = ROOT / "data" / "samples" / "dashboard_reviews.csv"
MAX_CALLS = int(os.getenv("DEMO_MAX_CALLS", "10"))
LANG = {"en": "English", "de": "German", "es": "Spanish", "fr": "French", "ja": "Japanese", "zh": "Chinese"}

INTRO = """# Customer Review Insights & Response Generator
Reads reviews in six languages, works out sentiment, topic and the issue behind a complaint, drafts a reply in the
customer's language, and spots sudden spikes. **Replies are drafts: negative reviews always go to a human first.**
Group 5, TalentSprint capstone. Sample reviews come from the Multilingual Amazon Reviews Corpus; review dates in the
spike tab are simulated."""


# --------------------------------------------------------------------------- #
# Tab 1: saved examples
# --------------------------------------------------------------------------- #
def example_labels() -> list[str]:
    return [f"{i + 1}. [{LANG[e['language']]}] {e['sentiment']}: {e['review_text'][:60].strip()}..."
            for i, e in enumerate(EXAMPLES)]


def judge_markdown(j: dict, status: str) -> str:
    flags = [name for name, on in (("promised an outcome", j.get("promises_outcome")),
                                   ("invented facts", j.get("invents_facts")),
                                   ("wrong language", j.get("wrong_language")),
                                   ("needs a human", j.get("needs_human_attention"))) if on]
    verdict = "accepted by the judge" if j.get("acceptable") else "**not accepted by the judge**"
    return (f"**Status:** `{status}`  \n**Judge (LLM-as-judge):** empathy {j.get('empathy')}, "
            f"specificity {j.get('specificity')}, correctness {j.get('correctness')}, tone {j.get('tone')} (1 to 5), "
            f"{verdict}.  \n**Flags:** {', '.join(flags) if flags else 'none'}  \n_{j.get('reason', '')}_")


def show_example(label: str):
    if not label:
        return "", "", "", "", ""
    e = EXAMPLES[example_labels().index(label)]
    analysis = (f"**Sentiment:** {e['sentiment']}  \n**Topic:** {e['topic']}  \n"
                f"**Estimated stars:** {e['stars_estimate']:.0f}  \n"
                f"**Issue:** {e['issue'] or '(not needed for non-negative reviews)'}  \n"
                f"**Language:** {LANG[e['language']]}")
    return e["review_text"], analysis, e["reply"], judge_markdown(e["judge"], e["status"]), e.get("customer_name") or ""


# --------------------------------------------------------------------------- #
# Tab 2: live analysis
# --------------------------------------------------------------------------- #
def analyse_live(text: str, name: str, use_judge: bool, code: str, used: int):
    empty = ("", "", "")
    text = (text or "").strip()
    if not text:
        return (*empty, "Paste a review first.", used)
    expected = os.getenv("DEMO_ACCESS_CODE")
    if expected and code != expected:
        return (*empty, "Wrong or missing access code.", used)
    if used >= MAX_CALLS:
        return (*empty, f"This session has used its {MAX_CALLS} live requests. Try the saved examples.", used)
    try:
        client = tracking.TrackedClient(api.get_client(), "analyze", api.CLASSIFY_PROMPT)
        c = api._classify(client, [{"id": "1", "text": text[:4000]}])[0]
        if "error" in c:
            return (*empty, "The model could not classify this review. Try again.", used + 1)
        result = api.draft_response(api.DraftRequest(text=text[:4000], customer_name=(name or "").strip() or None,
                                                     sentiment=c["sentiment"], topic=c["topic"], run_judge=use_judge))
    except (HTTPException, tracking.BudgetExceeded) as e:
        detail = getattr(e, "detail", str(e))
        return (*empty, f"Stopped: {detail}", used)
    except Exception as e:  # network or API error: show it instead of a stack trace
        return (*empty, f"Something went wrong ({type(e).__name__}). Try again.", used)
    analysis = (f"**Sentiment:** {result['sentiment']}  \n**Topic:** {result['topic']}  \n"
                f"**Estimated stars:** {c['stars_estimate']}  \n**Confidence:** {c['confidence']}  \n"
                f"**Issue:** {result['issue'] or '(not needed for non-negative reviews)'}")
    if result["judge"]:
        status = judge_markdown({**result["judge"], "reason": result["judge"].get("reason", "")}, result["status"])
    else:
        status = f"**Status:** `{result['status']}` (judge skipped, so the reply is held for a human)"
    note = f"Done. Spend so far on this server: ${tracking.spent_usd():.4f} of ${tracking.cap_usd():.2f}."
    return analysis, result["reply"], status, note, used + 1


# --------------------------------------------------------------------------- #
# Tab 3: spike detection
# --------------------------------------------------------------------------- #
def run_spikes(z_thresh: float, min_count: int):
    df = pd.read_csv(REVIEWS_CSV, parse_dates=["review_date"])
    neg = df[(df.sentiment == "negative") & df.issue_category.notna()]
    events = [api.TrendEvent(cluster=r.issue_category, date=r.review_date.date()) for r in neg.itertuples()]
    res = api.trends(api.TrendsRequest(events=events, z_thresh=float(z_thresh), min_count=int(min_count)))
    table = pd.DataFrame(res["spikes"])
    if table.empty:
        table = pd.DataFrame(columns=["issue", "week starting", "negative reviews", "previous week", "change", "baseline", "z"])
    else:
        table = table.rename(columns={"group": "issue", "week_start": "week starting", "count": "negative reviews",
                                      "prev_week": "previous week", "wow_delta": "change", "baseline_mean": "baseline"})[
            ["issue", "week starting", "negative reviews", "previous week", "change", "baseline", "z"]].sort_values("z", ascending=False)
    t0 = neg.review_date.min()
    weekly = (neg.assign(week=((neg.review_date - t0).dt.days // 7) + 1).groupby(["issue_category", "week"]).size()
              .rename("negative reviews").reset_index().rename(columns={"issue_category": "issue"}))
    weekly["week"] = weekly["week"].map(lambda w: f"W{int(w):02d}")
    return table, weekly


# --------------------------------------------------------------------------- #
# UI
# --------------------------------------------------------------------------- #
def build_ui() -> gr.Blocks:
    with gr.Blocks(title="Customer Review Insights & Response Generator") as demo:
        gr.Markdown(INTRO)
        with gr.Tabs():
            with gr.Tab("Saved examples (no API calls)"):
                pick = gr.Dropdown(choices=example_labels(), label="Pick a review")
                with gr.Row():
                    with gr.Column():
                        ex_review = gr.Textbox(label="Review", lines=5)
                        ex_name = gr.Textbox(label="Customer name (if given)")
                    with gr.Column():
                        ex_analysis = gr.Markdown(label="Analysis")
                        ex_reply = gr.Textbox(label="Drafted reply", lines=6)
                        ex_judge = gr.Markdown(label="Judge + status")
                pick.change(show_example, pick, [ex_review, ex_analysis, ex_reply, ex_judge, ex_name])

            with gr.Tab("Live analysis (uses Claude)"):
                with gr.Row():
                    live_text = gr.Textbox(label="Paste a review (any of the six languages)", lines=5)
                    with gr.Column():
                        live_name = gr.Textbox(label="Customer name (optional)")
                        live_judge = gr.Checkbox(value=True, label="Run the LLM judge")
                        live_code = gr.Textbox(label="Access code (only if the server sets one)", type="password")
                live_btn = gr.Button("Analyse and draft a reply", variant="primary")
                used = gr.State(0)
                with gr.Row():
                    with gr.Column():
                        live_analysis = gr.Markdown(label="Analysis")
                    with gr.Column():
                        live_reply = gr.Textbox(label="Drafted reply", lines=6)
                live_status = gr.Markdown()
                live_note = gr.Markdown()
                live_btn.click(analyse_live, [live_text, live_name, live_judge, live_code, used],
                               [live_analysis, live_reply, live_status, live_note, used])

            with gr.Tab("Spike detection (no API calls)"):
                with gr.Row():
                    z_in = gr.Slider(1.0, 6.0, value=3.5, step=0.1, label="z threshold")
                    min_in = gr.Slider(1, 40, value=8, step=1, label="minimum reviews in a week")
                spike_btn = gr.Button("Detect spikes", variant="primary")
                spike_table = gr.Dataframe(label="Flagged spikes")
                weekly_table = gr.Dataframe(label="Weekly negative-review counts by issue")
                spike_btn.click(run_spikes, [z_in, min_in], [spike_table, weekly_table])
    return demo


if __name__ == "__main__":
    build_ui().launch(server_name="0.0.0.0", server_port=7860)
