# Customer Review Insights & Response Generator (Group 5)

End-to-end, multilingual customer-review intelligence pipeline:

**aggregate reviews → detect language → translate → sentiment + topic analysis →
issue extraction → issue clustering → trend / spike detection → personalised
response drafts → LLM-as-judge guardrails → dashboard & Slack alerts.**

Built for the TalentSprint *Applied Generative AI & Agentic AI* capstone
(Cohort 6, Group 5). LLM: Anthropic Claude (Haiku 4.5 by default, Sonnet 5 for
the judge). The whole project also runs **fully offline** with a deterministic
heuristic engine, so every test, the demo and the pipeline work with **no API key
and no network** — ideal for grading and CI.

---

## 1. What problem does this solve?

A retailer receives thousands of reviews a day across 20+ platforms in six
languages. Manually reading them, spotting emerging problems and answering each
one is impossible at scale. This project turns that stream into:

| Capability | Output |
|---|---|
| Unified ingestion | One normalised schema from any source |
| Translation | English text for every review (EN, DE, ES, FR, JA, ZH) |
| Sentiment + topic | `negative / neutral / positive` + product topic |
| Issue extraction | A short phrase for each negative review |
| Issue clustering | Groups of similar complaints (sentence embeddings + k-means) |
| Trend detection | Weekly spike alerts vs a trailing 4-week baseline |
| Response drafting | Brand-voice reply per (sentiment × topic) |
| Guardrails | LLM-as-judge rubric + flags, human routing for negatives |

### Targets from the proposal

| Metric | Target | How it is measured |
|---|---|---|
| Throughput | 1,000+ reviews / day | Pipeline batch throughput |
| Sentiment accuracy | 85%+ (binary) | `scripts/eval_sentiment.py` |
| Response time | < 3 hours | Drafting is synchronous per review |
| Human acceptance | 80%+ | LLM-judge proxy (`scripts/eval_responses.py`) |

---

## 2. Repository layout

```
customer-review-insights/
├── src/
│   ├── config.py            # paths, languages, models, prices, targets
│   ├── schema.py            # unified review schema + Review dataclass
│   ├── ingestion/loader.py  # MARC / CSV / JSONL → unified schema
│   ├── translation/         # language detection + LLM translation
│   ├── analysis/
│   │   ├── sentiment.py     # TF-IDF baseline, LLM classifier, stacker
│   │   ├── clustering.py    # sentence embeddings + k-means / HDBSCAN
│   │   └── trends.py        # z-score + EWMA spike detection
│   ├── response/
│   │   ├── generate.py      # playbook grid + brand voice + status routing
│   │   └── judge.py         # LLM-as-judge rubric + guardrail flags
│   ├── llmops/
│   │   ├── llm_client.py    # Anthropic client + OfflineEngine fallback
│   │   └── tracking.py      # token/cost logging + hard spend cap
│   └── api/main.py          # FastAPI service
├── prompts/                 # versioned prompt templates + playbooks + taxonomy
├── n8n/                     # exported n8n workflows (01–04)
├── scripts/                 # download, eval, pipeline, space build/deploy
├── data/
│   ├── samples/             # checked-in sample data (works offline)
│   ├── raw/                 # git-ignored
│   └── processed/           # git-ignored pipeline artifacts
├── notebooks/               # EDA notebook
├── tests/                   # pytest suite (no API calls)
├── docs/                    # architecture, experiment log, final report
├── app.py                   # Gradio demo (3 tabs)
├── space/                   # Hugging Face Space config
├── requirements.txt
├── .env.example
└── .gitignore
```

---

## 3. Quick start

### 3.1 Offline (no keys, no network) — recommended for a first run

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 46 tests, none of which call Claude
pytest tests -q

# full pipeline on a small MARC sample, deterministic offline engine
python scripts/run_pipeline.py --per-star 6
```

Artifacts land in `data/processed/`:

| File | Contents |
|---|---|
| `unified_reviews.csv` | Normalised input reviews |
| `analyzed_reviews.csv` | Sentiment / topic / issue / cluster / reply per review |
| `cluster_summary.csv` | Cluster sizes, language mix, topic purity |
| `cluster_silhouette.csv` | k-selection scores |
| `trend_spikes.csv` | Precision / recall / Precision@k vs planted spikes |
| `trend_example_seed0.csv` | The flagged spikes for one seed |
| `reply_eval.csv`, `reply_eval.json` | Judge rubric + acceptance summary |
| `llm_calls.jsonl` | LLMOps call log (tokens, cost, latency) |

### 3.2 Live (real Claude calls)

```bash
cp .env.example .env          # then set ANTHROPIC_API_KEY
python scripts/check_keys.py  # smoke-tests the key
python scripts/run_pipeline.py --per-star 40 --live
```

Every call is priced and logged, and a hard `MAX_SPEND_USD` cap stops the run
before overspending.

---

## 4. The unified schema

Every source is normalised to:

```
review_id, source, product_category, rating, review_text,
detected_language, translated_text, review_date
```

`src/schema.py` defines the columns and a `Review` dataclass; `loader.py` maps
MARC rows (`id`, `text`, `label` → 1–5 stars), CSV/JSONL files with common column
names, and arbitrary dicts into that shape.

---

## 5. How each stage works

### 5.1 Ingestion
`src/ingestion/loader.py` reads the Multilingual Amazon Reviews Corpus (MARC)
from its Hugging Face mirror. MARC files are sorted by star rating, so the loader
takes a **stratified sample** (`per_star` per rating per language) instead of the
first N rows. If `datasets`/network is unavailable it falls back to the checked-in
`data/samples/marc_sample.csv`, so the pipeline always runs.

### 5.2 Translation
`src/translation/translate.py` detects the language, batches non-English reviews
(8 per call, `translate_v1`) and returns English text. English reviews are marked
`not_needed`; failures are recorded per review rather than crashing the batch.

### 5.3 Sentiment + topic
Three models are compared (`scripts/eval_sentiment.py`, `scripts/stack_sentiment.py`):

1. **Baseline** — TF-IDF (1–2 grams) + logistic regression, trained on MARC.
2. **LLM classifier** — `classify_v3` returns sentiment, topic, confidence, stars.
3. **Stacker** — logistic regression over the baseline probabilities plus the
   LLM's star estimate and confidence. This is the model the pipeline ships.

Ground truth comes from star ratings (1–2 negative, 3 neutral, 4–5 positive).

### 5.4 Issue extraction & clustering
Negative reviews get a short issue phrase (`issue_v1`). `src/analysis/clustering.py`
embeds issues with `paraphrase-multilingual-MiniLM-L12-v2` and clusters with
k-means (silhouette-scored) or HDBSCAN. If `sentence-transformers` is absent it
falls back to TF-IDF + SVD so clustering still works offline.

### 5.5 Trend detection
`src/analysis/trends.py` builds weekly counts per issue group and flags a week
when it exceeds the trailing `window` weeks by a **z-score** (`z ≥ 3.5`, count
`≥ min_count`) or an **EWMA** control limit. The standard deviation is floored at
`sqrt(mean)` (Poisson) so quiet groups don't produce false alarms. `evaluate()`
measures precision / recall / Precision@k against **planted** spikes.

### 5.6 Response generation
`src/response/generate.py` uses a **(sentiment × topic) playbook grid**
(`prompts/response/playbooks_v1.json`) and brand voice
(`prompts/response/brand.json`) to draft a reply. Negative reviews are routed to
`needs_review` (human approval); others are `auto_send`.

### 5.7 LLM-as-judge guardrails
`src/response/judge.py` scores each reply on **empathy, specificity, correctness,
tone** (1–5) and flags **promises_outcome, invents_facts, wrong_language,
needs_human_attention**. `acceptable()` is the automatic proxy for the 80%
human-acceptance target.

---

## 6. LLMOps

* **Prompt registry** — every prompt is a versioned file in `prompts/`
  (`classify_v1/v2/v3`, `translate_v1`, `issue_v1`, `judge_v1`, `response_v2`).
* **Spend cap** — `MAX_SPEND_USD` in `.env`; `src/llmops/tracking.py` raises
  `BudgetExceeded` before a call would exceed it.
* **Call log** — every call appends tokens, model, cost and latency to
  `data/processed/llm_calls.jsonl`.
* **Offline fallback** — `OfflineEngine` in `llm_client.py` returns the exact JSON
  shapes each prompt asks for, so tests and demos never need a key.

---

## 7. FastAPI service

```bash
export SERVICE_API_KEY=choose-a-key     # optional; callers send X-API-Key
export MAX_SPEND_USD=1.0
uvicorn src.api.main:app --port 8000
# interactive docs at http://localhost:8000/docs
```

| Endpoint | Purpose |
|---|---|
| `GET /health` | Liveness + LLM mode |
| `POST /analyze` | Sentiment + topic + issue for one review |
| `POST /draft-response` | Draft (and optionally judge) a reply |
| `POST /trends` | Flag spikes from a list of trend events |

---

## 8. Gradio demo & Hugging Face Space

`app.py` is a three-tab demo:

1. **Saved examples** — 13 real reviews with stored output (no API call).
2. **Live analysis** — classify + draft + optional judge (spend-capped).
3. **Spike detection** — the trend detector on dashboard data (no API call).

```bash
python app.py        # http://127.0.0.1:7860
```

Deploy to a free CPU Space:

1. `python scripts/build_space.py` builds `space_build/` (only the files the demo
   needs, no keys).
2. Create a Space (SDK **Gradio**, hardware **CPU basic**).
3. Add the secret `ANTHROPIC_API_KEY` (never commit it).
4. `python scripts/deploy_space.py` (needs `HF_TOKEN`) or upload `space_build/`.

---

## 9. n8n workflows (`n8n/`)

| File | What it does |
|---|---|
| `01_ingestion_marc_to_unified_schema.json` | Fetch MARC from HF, sample per star, emit unified schema. No credentials. |
| `02_ingestion_and_translation.json` | 01 + Claude translation of non-English reviews (batches of 8, per-review failure recording). |
| `03_full_pipeline.json` | 02 + sentiment/topic, issue category, reply drafts, status, summary with accuracy/cost/timing. |
| `04_trend_detection_slack_alert.json` | Read dashboard reviews, detect negative spikes (z ≥ 3.5, ≥ 8, trailing 4 weeks), post to Slack. |

Import via n8n → Workflows → Create → `...` → **Import from file**, then Execute.

---

## 10. Tests

```bash
pytest tests -q          # 46 tests, none call Claude
```

Covers the schema/loader, the offline LLM client, sentiment, clustering, trends,
response generation, the judge, the FastAPI service and the demo app.

---

## 11. Docs

* `docs/architecture.md` — component and data-flow diagrams.
* `docs/experiment_log.md` — every method tried and the numbers behind decisions.
* `docs/final/` — the final project report.

---

## 12. Environment variables (`.env`)

See `.env.example`. Key ones: `ANTHROPIC_API_KEY`, `LLM_MODEL`,
`JUDGE_MODEL`, `MAX_SPEND_USD`, `SERVICE_API_KEY`, `DEMO_MAX_CALLS`,
`HF_TOKEN`, `OFFLINE` (`auto` / `1` / `0`).

---

## 13. License & credits

Capstone project for TalentSprint Cohort 6, Group 5. Data: Multilingual Amazon
Reviews Corpus (Keung et al., 2020). LLM: Anthropic Claude.
