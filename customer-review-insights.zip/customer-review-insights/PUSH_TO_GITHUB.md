# How to push this project to your own GitHub repository

This repository is already a complete, committed Git repo. You only need to point
it at your GitHub account and push. Pick **one** of the three options below.

---

## Option A — GitHub website + this zip (no command line)

1. Unzip `customer-review-insights.zip` somewhere on your machine.
2. On GitHub, click **New repository**. Give it a name (e.g.
   `Capstone_Project_Group_5`), keep it **Public**, and **do not** add a README
   or `.gitignore` (this repo already has them).
3. On the new empty repo page click **uploading an existing file**.
4. Drag the **contents** of the unzipped folder into the browser (or use the
   GitHub Desktop app). Commit.

> Note: the website uploader can be fiddly with many files. If it struggles, use
> Option B or C.

---

## Option B — push from the command line (HTTPS)

```bash
# 1. Create an EMPTY repo on GitHub first (no README, no .gitignore).
#    Copy its URL, e.g. https://github.com/<you>/Capstone_Project_Group_5.git

# 2. Unzip and enter the project
unzip customer-review-insights.zip
cd customer-review-insights

# 3. Point the existing repo at your GitHub repo
git remote add origin https://github.com/<you>/Capstone_Project_Group_5.git
git branch -M main
git push -u origin main
```

When prompted, use a **Personal Access Token** as the password
(GitHub → Settings → Developer settings → Personal access tokens → Fine-grained
tokens → repo: Contents read/write). Regular passwords no longer work.

---

## Option C — push with the GitHub CLI

```bash
unzip customer-review-insights.zip
cd customer-review-insights

gh auth login                 # follow the prompts
gh repo create Capstone_Project_Group_5 --public --source=. --remote=origin --push
```

---

## Verify

```bash
git remote -v          # should show your GitHub URL
git log --oneline      # should show the initial commit
```

Then refresh your GitHub repo page — all files should be there.

---

## If you want to change the commit author

```bash
git config user.name  "Your Name"
git config user.email "you@example.com"
git commit --amend --reset-author --no-edit
git push -u origin main
```

---

## What is (and is not) committed

Committed: all source, prompts, n8n workflows, scripts, tests, docs, notebook and
the checked-in sample data under `data/samples/`.

Ignored on purpose (see `.gitignore`): `.env` (secrets), `.venv/`,
`__pycache__/`, `data/raw/`, `data/processed/` (regenerable) and `space_build/`.

Never commit your `ANTHROPIC_API_KEY` — keep it in `.env`, which is ignored.
