"""Translation layer: detect the language of each review and translate non-English
reviews to English with the LLM (translate-then-analyze).

The proposal compares translate-then-analyze against the native multilingual
model; this module implements the translate side and records the detected
language so downstream stages can use either text.
"""
from __future__ import annotations

import json
from typing import Optional

import pandas as pd

from src import config
from src.llmops import tracking
from src.llmops.llm_client import detect_language, get_client, parse_json, text_of

PROMPT_VERSION = "translate_v1"
BATCH_SIZE = 8


def _system_prompt() -> str:
    return (config.PROMPTS_DIR / f"{PROMPT_VERSION}.txt").read_text(encoding="utf-8")


def translate_batch(client, reviews: list[dict]) -> list[dict]:
    """Translate up to ``BATCH_SIZE`` reviews in one call."""
    payload = [{"id": r["review_id"], "text": r["review_text"]} for r in reviews]
    resp = client.messages.create(
        model=config.LLM_MODEL, max_tokens=4000, system=_system_prompt(),
        messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
    )
    items = {t["id"]: t for t in parse_json(text_of(resp))["translations"]}
    out = []
    for r in reviews:
        t = items.get(r["review_id"])
        out.append({
            **r,
            "translated_text": t["english"] if t else None,
            "translation_language": t["language"] if t else None,
            "translation_status": "ok" if t else "failed",
        })
    return out


def translate_reviews(df: pd.DataFrame, client=None, use_tracking: bool = True) -> pd.DataFrame:
    """Add ``translated_text`` to every row. English rows pass through untouched."""
    client = client or get_client()
    if use_tracking:
        client = tracking.TrackedClient(client, "translate", PROMPT_VERSION)

    rows = df.to_dict("records")
    out: list[dict] = []
    pending: list[dict] = []

    for r in rows:
        lang = r.get("detected_language") or detect_language(r["review_text"])
        r["detected_language"] = lang
        if lang == "en":
            r.update(translated_text=r["review_text"], translation_language="en",
                     translation_status="not_needed")
            out.append(r)
        else:
            pending.append(r)

    for i in range(0, len(pending), BATCH_SIZE):
        batch = pending[i:i + BATCH_SIZE]
        try:
            out.extend(translate_batch(client, batch))
        except Exception as exc:  # a failed batch is recorded per review, not fatal
            for r in batch:
                out.append({**r, "translated_text": None, "translation_language": None,
                            "translation_status": "failed", "translation_error": str(exc)[:200]})

    result = pd.DataFrame(out)
    return result


def summary(df: pd.DataFrame) -> dict:
    status = df["translation_status"].value_counts().to_dict() if "translation_status" in df else {}
    return {"total": len(df), "by_status": status}
