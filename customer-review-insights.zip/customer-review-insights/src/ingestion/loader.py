"""Ingestion: pull reviews from their sources and normalise to the unified schema.

Sources supported:
  * MARC (Multilingual Amazon Reviews Corpus) from the Hugging Face mirror
    ``mteb/amazon_reviews_multi`` -- the primary corpus (1.26M reviews, 6 languages).
  * Local CSV/JSON files already in (or convertible to) the unified schema.
  * Synthetic reviews (see :mod:`scripts.generate_synthetic_reviews`).

The reference n8n workflows download the same MARC files; review ids, stars and
text are identical, so results are interchangeable.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Optional

import pandas as pd

from src import config
from src.schema import UNIFIED_COLUMNS

# The Hugging Face mirror stores one JSONL file per language/split. Files are
# sorted by label, so callers must sample per star rating rather than take the
# first N rows (otherwise you get 100% 1-star reviews).
HF_BASE = "https://huggingface.co/datasets/mteb/amazon_reviews_multi/resolve/main"


def _normalise_row(row: dict, lang: Optional[str] = None) -> dict:
    """Map a raw MARC row (id, text, label) to the unified schema."""
    rating = row.get("rating", row.get("label"))
    if rating is not None:
        rating = int(rating) + 1 if row.get("label") is not None and "rating" not in row else int(rating)
    text = str(row.get("review_text", row.get("text", ""))).strip()
    return {
        "review_id": str(row.get("review_id") or row.get("id") or ""),
        "source": row.get("source", "marc"),
        "product_category": row.get("product_category"),
        "rating": rating,
        "review_text": text,
        "detected_language": row.get("detected_language", lang),
        "translated_text": row.get("translated_text"),
        "review_date": row.get("review_date"),
    }


def load_marc(lang: str, split: str = "test", per_star: int = 40, seed: int = 42,
              offline_path: Optional[Path] = None) -> pd.DataFrame:
    """Load a stratified sample of MARC for one language.

    Tries the Hugging Face ``datasets`` loader first; if that is unavailable
    (no network, or the legacy loading script is rejected by datasets 5.x) it
    falls back to a checked-in local sample so the pipeline still runs.
    """
    rows: list[dict] = []
    try:  # pragma: no cover - depends on network/datasets version
        from datasets import load_dataset

        ds = load_dataset("json", data_files=f"{config.MARC_HF_TEMPLATE.format(lang=lang, split=split)}", split="train")
        raw = ds.to_pandas()
        for label, group in raw.groupby("label"):
            take = group.sample(n=min(per_star, len(group)), random_state=seed)
            for _, r in take.iterrows():
                rows.append(_normalise_row({"id": r["id"], "text": r["text"], "label": int(label)}, lang))
    except Exception:  # offline fallback
        rows = _load_local_sample(lang, per_star, seed, offline_path)

    df = pd.DataFrame(rows)
    return df.reindex(columns=UNIFIED_COLUMNS)


def _load_local_sample(lang: str, per_star: int, seed: int, offline_path: Optional[Path]) -> list[dict]:
    path = offline_path or (config.SAMPLES_DIR / "marc_sample.csv")
    if not Path(path).exists():
        return []
    df = pd.read_csv(path)
    df = df[df.detected_language == lang]
    out = []
    for rating, group in df.groupby("rating"):
        take = group.sample(n=min(per_star, len(group)), random_state=seed)
        out.extend(take.to_dict("records"))
    return out


def load_marc_all(per_star: int = 40, split: str = "test", seed: int = 42) -> pd.DataFrame:
    """Load the stratified MARC sample for all six languages."""
    frames = [load_marc(lang, split=split, per_star=per_star, seed=seed) for lang in config.LANGUAGES]
    return pd.concat(frames, ignore_index=True)


def load_csv(path: str | Path) -> pd.DataFrame:
    """Load a file already in the unified schema (or close to it)."""
    df = pd.read_csv(path)
    rename = {"text": "review_text", "language": "detected_language", "stars": "rating", "id": "review_id"}
    df = df.rename(columns={k: v for k, v in rename.items() if k in df.columns and v not in df.columns})
    if "review_id" in df.columns:
        df["review_id"] = df["review_id"].astype(str)
    for col in UNIFIED_COLUMNS:
        if col not in df.columns:
            df[col] = None
    return df[UNIFIED_COLUMNS + [c for c in df.columns if c not in UNIFIED_COLUMNS]]


def load_jsonl(path: str | Path) -> pd.DataFrame:
    rows = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    return pd.DataFrame(rows)


def to_unified(records: Iterable[dict], source: str = "manual") -> pd.DataFrame:
    """Normalise an arbitrary iterable of dicts into the unified schema."""
    out = []
    for r in records:
        d = _normalise_row({**r, "source": r.get("source", source)})
        out.append(d)
    return pd.DataFrame(out).reindex(columns=UNIFIED_COLUMNS)
