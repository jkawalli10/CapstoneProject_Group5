"""LLM-as-judge for drafted replies.

The judge scores each reply on a four-dimension rubric (empathy, specificity,
correctness, tone; 1-5) and reports four guardrail flags (promises_outcome,
invents_facts, wrong_language, needs_human_attention). ``acceptable`` turns those
into an automatic proxy for the proposal's 80% human-acceptance metric, and
``evaluate_replies`` aggregates a whole batch into a report.
"""
from __future__ import annotations

import json
from typing import Optional

import pandas as pd

from src import config
from src.llmops import tracking
from src.llmops.llm_client import get_client, parse_json, text_of

JUDGE_VERSION = "judge_v1"
DIMENSIONS = ["empathy", "specificity", "correctness", "tone"]
FLAGS = ["promises_outcome", "invents_facts", "wrong_language", "needs_human_attention"]
PROMPT_VERSION = JUDGE_VERSION


def load_prompt() -> str:
    return (config.PROMPTS_DIR / f"{JUDGE_VERSION}.txt").read_text(encoding="utf-8")


def score_reply(client, review: dict, reply: str, system: Optional[str] = None) -> dict:
    """Return the judge's score dict for one (review, reply) pair."""
    payload = {
        "review": (review.get("review_text") or "")[:1500],
        "reply": reply,
        "sentiment": review.get("sentiment"),
        "topic": review.get("topic"),
        "customer_name": review.get("customer_name"),
    }
    resp = client.messages.create(
        model=config.JUDGE_MODEL, max_tokens=2000, system=system or load_prompt(),
        messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
    )
    return parse_json(text_of(resp))


def acceptable(scores: dict) -> bool:
    """Automatic proxy for human acceptance: every dimension >= 4 and no
    guardrail flag except ``needs_human_attention`` (which routes to a human)."""
    return (all(scores.get(d, 0) >= 4 for d in DIMENSIONS)
            and not scores.get("promises_outcome") and not scores.get("invents_facts")
            and not scores.get("wrong_language"))


def judge_replies(df: pd.DataFrame, client=None, use_tracking: bool = True) -> pd.DataFrame:
    """Score every row that already has a ``reply``."""
    client = client or get_client()
    if use_tracking:
        client = tracking.TrackedClient(client, "judge", PROMPT_VERSION)
    system = load_prompt()
    out = []
    for r in df.to_dict("records"):
        reply = r.get("reply")
        if not reply:
            out.append(r)
            continue
        try:
            scores = score_reply(client, r, reply, system)
        except Exception as exc:  # pragma: no cover - network failure path
            out.append({**r, "judge_error": str(exc)[:200]})
            continue
        out.append({**r, **{f"judge_{k}": v for k, v in scores.items()}})
    return pd.DataFrame(out)


def evaluate_replies(df: pd.DataFrame) -> dict:
    """Aggregate rubric scores and guardrail rates over a batch."""
    if df.empty:
        return {"n": 0}
    dims = {d: round(float(df[f"judge_{d}"].mean()), 2) for d in DIMENSIONS if f"judge_{d}" in df.columns}
    flags = {f: round(float(df[f"judge_{f}"].mean()), 3) for f in FLAGS if f"judge_{f}" in df.columns}
    acc = None
    if all(f"judge_{d}" in df.columns for d in DIMENSIONS):
        def _row_ok(r):
            scores = {d: r.get(f"judge_{d}") for d in DIMENSIONS}
            scores.update({f: bool(r.get(f"judge_{f}")) for f in FLAGS})
            return acceptable(scores)
        acc = round(float(df.apply(_row_ok, axis=1).mean()), 3)
    return {"n": len(df), "mean_scores": dims, "flag_rates": flags,
            "acceptance_rate": acc, "target": config.TARGET_HUMAN_ACCEPTANCE}
