"""Response drafting: choose the (sentiment x topic) playbook, apply the brand
voice and ask the LLM for a reply.

The playbook grid is the guardrail backbone. Each cell tells the model what to
focus on, what to do and what to avoid, so a negative shipping complaint never
gets the same treatment as glowing praise. ``generate_replies`` runs the whole
batch and attaches a ``reply_status``:

* ``auto_send``    -- positive/neutral, guardrails clean (still human-visible).
* ``needs_review`` -- negative sentiment or any guardrail flag; a human must
  approve before anything is sent (the proposal's 80% human-acceptance target).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import pandas as pd

from src import config
from src.llmops import tracking
from src.llmops.llm_client import get_client, parse_json, text_of

RESPONSE_DIR = config.PROMPTS_DIR / "response"
VERSION = "v2"
SYSTEM_VERSION = f"system_{VERSION}"
TOPICS = set(config.TOPICS)
PROMPT_VERSION = f"response_{VERSION}"


# --------------------------------------------------------------------------- #
# Assets
# --------------------------------------------------------------------------- #
def load_assets(version: str = VERSION) -> dict:
    """Load the brand brief, system prompt and playbook grid."""
    brand = json.loads((RESPONSE_DIR / "brand.json").read_text(encoding="utf-8"))
    system = (RESPONSE_DIR / f"system_{version}.txt").read_text(encoding="utf-8")
    for key, value in brand.items():
        system = system.replace("{" + key + "}", value)
    playbooks_path = RESPONSE_DIR / f"playbooks_{version}.json"
    if not playbooks_path.exists():
        playbooks_path = RESPONSE_DIR / "playbooks_v1.json"
    return {"system": system, "playbooks": json.loads(playbooks_path.read_text(encoding="utf-8")),
            "brand": brand}


def playbook_for(review: dict, playbooks: dict) -> str:
    topic = review.get("topic") if review.get("topic") in TOPICS else "other"
    sentiment = review.get("sentiment") or "neutral"
    key = f"{sentiment}/{topic}"
    return playbooks.get(key) or playbooks.get(f"{sentiment}/other") or playbooks["neutral/other"]


def build_user_message(review: dict, assets: dict) -> str:
    topic = review.get("topic") if review.get("topic") in TOPICS else "other"
    payload = {
        "review": (review.get("review_text") or "")[:1500],
        "customer_name": review.get("customer_name"),
        "sentiment": review.get("sentiment"),
        "topic": topic,
        "issue": review.get("issue"),
        "playbook": playbook_for({**review, "topic": topic}, assets["playbooks"]),
    }
    return json.dumps(payload, ensure_ascii=False)


# --------------------------------------------------------------------------- #
# Drafting
# --------------------------------------------------------------------------- #
def draft(client, review: dict, assets: dict, model: Optional[str] = None) -> str:
    """Return the drafted reply text for one review."""
    resp = client.messages.create(
        model=model or config.LLM_MODEL, max_tokens=600, system=assets["system"],
        messages=[{"role": "user", "content": build_user_message(review, assets)}],
    )
    try:
        return parse_json(text_of(resp))["reply"].strip()
    except Exception:  # pragma: no cover - malformed model output
        return text_of(resp).strip()


def _status(review: dict, judge_scores: Optional[dict]) -> str:
    if review.get("sentiment") == "negative":
        return "needs_review"
    if judge_scores and (judge_scores.get("promises_outcome") or judge_scores.get("invents_facts")
                         or judge_scores.get("wrong_language")):
        return "needs_review"
    return "auto_send"


def generate_replies(df: pd.DataFrame, client=None, assets: Optional[dict] = None,
                     use_tracking: bool = True, judge: bool = False, judge_client=None) -> pd.DataFrame:
    """Draft a reply for every review and attach ``reply`` + ``reply_status``.

    Set ``judge=True`` to also run the LLM-as-judge and store its rubric scores
    (``judge_*`` columns) and the guardrail flags.
    """
    client = client or get_client()
    if use_tracking:
        client = tracking.TrackedClient(client, "reply", PROMPT_VERSION)
    assets = assets or load_assets()

    rows = df.to_dict("records")
    out = []
    for r in rows:
        try:
            reply = draft(client, r, assets)
            status = _status(r, None)
        except Exception as exc:  # pragma: no cover - network failure path
            reply, status = None, "failed"
            r = {**r, "reply_error": str(exc)[:200]}
        rec = {**r, "reply": reply, "reply_status": status}
        if judge and reply:
            from src.response import judge as judge_mod

            scores = judge_mod.score_reply(judge_client or get_client(), r, reply, judge_mod.load_prompt())
            rec.update({f"judge_{k}": v for k, v in scores.items()})
            rec["reply_status"] = _status(r, scores)
        out.append(rec)
    return pd.DataFrame(out)


def summary(df: pd.DataFrame) -> dict:
    status = df["reply_status"].value_counts().to_dict() if "reply_status" in df.columns else {}
    return {"total": len(df), "by_status": status}
