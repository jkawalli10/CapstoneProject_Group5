"""The unified review schema every source is normalised into.

    review_id, source, product_category, rating, review_text,
    detected_language, translated_text, review_date

Additional derived columns (sentiment, topic, issue, cluster, reply, ...) are
added by the analysis stages and documented in :data:`ANALYSIS_COLUMNS`.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Optional

UNIFIED_COLUMNS = [
    "review_id",
    "source",
    "product_category",
    "rating",
    "review_text",
    "detected_language",
    "translated_text",
    "review_date",
]

ANALYSIS_COLUMNS = [
    "sentiment",
    "stars_estimate",
    "confidence",
    "topic",
    "issue",
    "cluster_id",
    "cluster_label",
    "reply",
    "reply_status",
]


@dataclass
class Review:
    """One customer review in the unified schema."""

    review_id: str
    source: str
    review_text: str
    rating: Optional[int] = None
    detected_language: Optional[str] = None
    product_category: Optional[str] = None
    translated_text: Optional[str] = None
    review_date: Optional[str] = None
    # analysis fields (filled in later stages)
    sentiment: Optional[str] = None
    stars_estimate: Optional[float] = None
    confidence: Optional[float] = None
    topic: Optional[str] = None
    issue: Optional[str] = None
    cluster_id: Optional[int] = None
    cluster_label: Optional[str] = None
    reply: Optional[str] = None
    reply_status: Optional[str] = None
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("extra", None)
        return d


def stars_to_label(stars: float) -> str:
    """Map a 1-5 star rating to a three-tier sentiment label."""
    s = int(round(min(max(float(stars), 1), 5)))
    return "negative" if s <= 2 else "neutral" if s == 3 else "positive"
