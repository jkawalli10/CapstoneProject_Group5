"""Sentiment analysis: a TF-IDF + logistic-regression baseline, an LLM few-shot
classifier, and a "stacker" that combines the two.

Three interchangeable predictors are provided so the proposal's comparison table
can be reproduced:

* :func:`train_baseline` / :func:`predict_baseline` -- classic TF-IDF (word +
  character n-grams) feeding a multinomial logistic regression. Cheap, fast and
  language-agnostic enough to be a strong baseline.
* :func:`classify_llm` -- Claude with the versioned ``classify`` prompt. Returns
  sentiment, topic, confidence and an estimated star rating.
* :func:`train_stacker` / :func:`predict_stacker` -- a logistic regression over
  the baseline's predicted probabilities concatenated with the LLM's estimated
  star rating and confidence. This is the model that clears the 85% target.

Ground truth for evaluation is the MARC star rating mapped through
:data:`src.config.STAR_TO_LABEL`.
"""
from __future__ import annotations

import json
from typing import Optional

import numpy as np
import pandas as pd

from src import config
from src.llmops import tracking
from src.llmops.llm_client import detect_language, get_client, parse_json, text_of
from src.schema import stars_to_label

PROMPT_VERSION = "classify_v3"  # v3 asks for the estimated star rating too
BATCH_SIZE = 10
LABELS = ["negative", "neutral", "positive"]


# --------------------------------------------------------------------------- #
# Prompt plumbing
# --------------------------------------------------------------------------- #
def _system_prompt(version: str = PROMPT_VERSION) -> str:
    return (config.PROMPTS_DIR / f"{version}.txt").read_text(encoding="utf-8")


def _text_column(df: pd.DataFrame) -> str:
    """Prefer the English translation, fall back to the original text."""
    if "translated_text" in df.columns and df["translated_text"].notna().any():
        return "translated_text"
    return "review_text"


def _row_text(row: dict, col: str) -> str:
    return str(row.get(col) or row.get("review_text") or "")


# --------------------------------------------------------------------------- #
# TF-IDF + logistic-regression baseline
# --------------------------------------------------------------------------- #
def train_baseline(df: pd.DataFrame, text_col: Optional[str] = None, seed: int = 42):
    """Fit the TF-IDF + logistic-regression baseline on labelled rows.

    ``df`` must contain a ``rating`` column (or a ``sentiment`` column already in
    ``{negative, neutral, positive}``). Returns ``(pipeline, text_col)``.
    """
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline

    text_col = text_col or _text_column(df)
    df = df.copy()
    if "sentiment" in df.columns and df["sentiment"].notna().any():
        y = df["sentiment"].astype(str)
    else:
        y = df["rating"].apply(lambda r: stars_to_label(int(r)))
    X = df[text_col].fillna("").astype(str)

    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(
            ngram_range=(1, 2), min_df=2, max_features=60000,
            sublinear_tf=True, strip_accents="unicode")),
        ("clf", LogisticRegression(max_iter=1000, C=4.0, class_weight="balanced",
                                   random_state=seed)),
    ])
    pipe.fit(X, y)
    return pipe, text_col


def predict_baseline(pipe, df: pd.DataFrame, text_col: Optional[str] = None) -> pd.DataFrame:
    """Add ``baseline_sentiment`` and per-class probabilities ``p_negative`` etc."""
    text_col = text_col or _text_column(df)
    X = df[text_col].fillna("").astype(str)
    probs = pipe.predict_proba(X)
    classes = list(pipe.named_steps["clf"].classes_)
    out = df.copy()
    out["baseline_sentiment"] = [classes[i] for i in probs.argmax(axis=1)]
    for i, c in enumerate(classes):
        out[f"p_{c}"] = probs[:, i]
    return out


# --------------------------------------------------------------------------- #
# LLM classifier
# --------------------------------------------------------------------------- #
def classify_batch(client, reviews: list[dict], text_col: str) -> list[dict]:
    payload = [{"id": r["review_id"], "text": _row_text(r, text_col)} for r in reviews]
    resp = client.messages.create(
        model=config.LLM_MODEL, max_tokens=2000, system=_system_prompt(),
        messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
    )
    items = {c["id"]: c for c in parse_json(text_of(resp))["classifications"]}
    out = []
    for r in reviews:
        c = items.get(r["review_id"], {})
        out.append({
            **r,
            "sentiment": c.get("sentiment"),
            "topic": c.get("topic"),
            "confidence": c.get("confidence"),
            "stars_estimate": c.get("stars"),
            "classify_status": "ok" if c else "failed",
        })
    return out


def classify_llm(df: pd.DataFrame, client=None, text_col: Optional[str] = None,
                 use_tracking: bool = True, prompt_version: str = PROMPT_VERSION) -> pd.DataFrame:
    """Run the LLM classifier over every row (batched)."""
    global PROMPT_VERSION
    PROMPT_VERSION = prompt_version
    client = client or get_client()
    if use_tracking:
        client = tracking.TrackedClient(client, "classify", prompt_version)
    text_col = text_col or _text_column(df)

    rows = df.to_dict("records")
    out: list[dict] = []
    for i in range(0, len(rows), BATCH_SIZE):
        batch = rows[i:i + BATCH_SIZE]
        try:
            out.extend(classify_batch(client, batch, text_col))
        except Exception as exc:  # pragma: no cover - network failure path
            for r in batch:
                out.append({**r, "sentiment": None, "topic": None, "confidence": None,
                            "stars_estimate": None, "classify_status": "failed",
                            "classify_error": str(exc)[:200]})
    return pd.DataFrame(out)


# --------------------------------------------------------------------------- #
# Stacker
# --------------------------------------------------------------------------- #
def _stacker_features(df: pd.DataFrame) -> np.ndarray:
    cols = []
    for c in LABELS:
        col = f"p_{c}"
        cols.append(df[col].to_numpy(dtype=float) if col in df.columns
                    else np.full(len(df), 1 / 3))
    stars = df["stars_estimate"].fillna(3).to_numpy(dtype=float) if "stars_estimate" in df.columns \
        else np.full(len(df), 3.0)
    conf = df["confidence"].fillna(0.5).to_numpy(dtype=float) if "confidence" in df.columns \
        else np.full(len(df), 0.5)
    return np.column_stack([*cols, stars, conf])


def train_stacker(df: pd.DataFrame, seed: int = 42):
    """Fit the stacker on rows that already have baseline probs + LLM output."""
    from sklearn.linear_model import LogisticRegression

    X = _stacker_features(df)
    y = df["sentiment"].astype(str) if "sentiment" in df.columns and df["sentiment"].notna().any() \
        else df["rating"].apply(lambda r: stars_to_label(int(r)))
    clf = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=seed)
    clf.fit(X, y)
    return clf


def predict_stacker(clf, df: pd.DataFrame) -> pd.DataFrame:
    X = _stacker_features(df)
    probs = clf.predict_proba(X)
    classes = list(clf.classes_)
    out = df.copy()
    out["stacked_sentiment"] = [classes[i] for i in probs.argmax(axis=1)]
    out["stacked_confidence"] = probs.max(axis=1).round(3)
    return out


# --------------------------------------------------------------------------- #
# Evaluation
# --------------------------------------------------------------------------- #
def evaluate(pred: pd.Series, truth: pd.Series, labels: list[str] = LABELS) -> dict:
    """Accuracy and macro-F1 for one prediction column."""
    from sklearn.metrics import accuracy_score, f1_score, confusion_matrix

    mask = pred.notna() & truth.notna()
    pred, truth = pred[mask], truth[mask]
    if len(pred) == 0:
        return {"n": 0, "accuracy": float("nan"), "macro_f1": float("nan")}
    return {
        "n": int(len(pred)),
        "accuracy": round(float(accuracy_score(truth, pred)), 4),
        "macro_f1": round(float(f1_score(truth, pred, average="macro", labels=labels, zero_division=0)), 4),
        "confusion": confusion_matrix(truth, pred, labels=labels).tolist(),
        "labels": labels,
    }


def evaluate_by_language(df: pd.DataFrame, pred_col: str, truth_col: str = "truth") -> pd.DataFrame:
    """Per-language accuracy / macro-F1 table (the proposal reports per language)."""
    rows = []
    langs = df["detected_language"].fillna("en") if "detected_language" in df.columns else pd.Series(["en"] * len(df))
    for lang in sorted(langs.unique()):
        sub = df[langs == lang]
        m = evaluate(sub[pred_col], sub[truth_col])
        rows.append({"language": lang, **{k: m[k] for k in ("n", "accuracy", "macro_f1")}})
    overall = evaluate(df[pred_col], df[truth_col])
    rows.append({"language": "ALL", **{k: overall[k] for k in ("n", "accuracy", "macro_f1")}})
    return pd.DataFrame(rows)


def add_truth(df: pd.DataFrame) -> pd.DataFrame:
    """Attach the star-derived ground-truth label used for evaluation."""
    out = df.copy()
    out["truth"] = out["rating"].apply(lambda r: stars_to_label(int(r)) if pd.notna(r) else None)
    return out


def compare_models(df: pd.DataFrame) -> pd.DataFrame:
    """Build the baseline-vs-LLM-vs-stacker comparison table."""
    rows = []
    for name, col in (("tfidf_baseline", "baseline_sentiment"),
                      ("llm_few_shot", "sentiment"),
                      ("stacker", "stacked_sentiment")):
        if col in df.columns:
            m = evaluate(df[col], df["truth"])
            rows.append({"model": name, "n": m["n"], "accuracy": m["accuracy"], "macro_f1": m["macro_f1"]})
    return pd.DataFrame(rows)
