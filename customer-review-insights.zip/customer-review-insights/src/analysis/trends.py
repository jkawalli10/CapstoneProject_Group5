"""Trend detection: find emerging issues before they become crises.

The core idea is simple and robust. For every issue group we build a weekly
count series, then compare each week with the trailing ``window`` weeks:

* **z-score rule** -- flag when ``z >= z_thresh`` *and* the raw count is at least
  ``min_count``. The standard deviation is floored at ``sqrt(mean)`` (the Poisson
  assumption) so a quiet group with a couple of extra reviews does not produce a
  giant z-score.
* **EWMA rule** -- an exponentially weighted moving average of the counts above a
  control limit ``mean + L * sd * sqrt(alpha / (2 - alpha))``.

``assign_timeline`` and ``evaluate`` let the detector be tested against *planted*
spikes, which is how the proposal validates precision/recall and Precision@k.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


# --------------------------------------------------------------------------- #
# Building a timeline (for tests / synthetic data)
# --------------------------------------------------------------------------- #
def assign_timeline(df: pd.DataFrame, cluster_col: str, spikes: list[dict],
                    n_weeks: int = 12, seed: int = 0) -> pd.Series:
    """Give every review a week 0..n_weeks-1.

    Reviews are spread uniformly, then for each planted spike
    ``{cluster, week, factor}`` extra reviews of that cluster are moved into the
    spike week until its count is about ``factor`` times the normal weekly count.
    """
    rng = np.random.default_rng(seed)
    week = pd.Series(rng.integers(0, n_weeks, len(df)), index=df.index)
    for sp in spikes:
        idx = df.index[df[cluster_col] == sp["cluster"]]
        normal = len(idx) / n_weeks
        target = int(round(sp["factor"] * normal))
        already = int((week[idx] == sp["week"]).sum())
        movable = [i for i in idx if week[i] != sp["week"]]
        if movable:
            move = rng.choice(movable, size=min(max(target - already, 0), len(movable)), replace=False)
            week.loc[move] = sp["week"]
    return week


def weekly_counts(df: pd.DataFrame, week: pd.Series, group_col: str, n_weeks: int = 12) -> pd.DataFrame:
    """Rows = weeks, columns = groups (e.g. clusters or issue phrases)."""
    return pd.crosstab(week, df[group_col]).reindex(range(n_weeks), fill_value=0)


def weekly_counts_from_dates(df: pd.DataFrame, group_col: str, date_col: str = "review_date",
                              freq: str = "W") -> pd.DataFrame:
    """Real-data variant: bucket ``review_date`` into ISO weeks and cross-tab."""
    d = df.copy()
    d[date_col] = pd.to_datetime(d[date_col], errors="coerce")
    d = d.dropna(subset=[date_col])
    d["week"] = d[date_col].dt.to_period(freq).dt.start_time
    return pd.crosstab(d["week"], d[group_col])


# --------------------------------------------------------------------------- #
# Spike detection
# --------------------------------------------------------------------------- #
def detect_spikes(counts: pd.DataFrame, window: int = 4, z_thresh: float = 3.5,
                  min_count: int = 8, alpha: float = 0.3, ewma_L: float = 3.0) -> pd.DataFrame:
    """For each group and week ``t >= window`` compare with the trailing window.

    Returns one row per (group, week) with the count, week-over-week delta,
    baseline mean, z-score and the two boolean flags.
    """
    rows = []
    for g in counts.columns:
        x = counts[g].to_numpy(dtype=float)
        if len(x) <= window:
            continue
        ewma = x[:window].mean()
        for t in range(window):
            ewma = alpha * x[t] + (1 - alpha) * ewma
        for t in range(window, len(x)):
            base = x[t - window:t]
            mu = base.mean()
            sd = max(base.std(ddof=1) if len(base) > 1 else 0.0, np.sqrt(max(mu, 1.0)))
            z = (x[t] - mu) / sd
            ewma = alpha * x[t] + (1 - alpha) * ewma
            ucl = mu + ewma_L * sd * np.sqrt(alpha / (2 - alpha))
            rows.append({
                "group": g, "week": t, "count": int(x[t]), "prev_week": int(x[t - 1]),
                "wow_delta": int(x[t] - x[t - 1]), "baseline_mean": round(mu, 2),
                "z": round(float(z), 2),
                "flag_z": bool(z >= z_thresh and x[t] >= min_count),
                "flag_ewma": bool(ewma > ucl and x[t] >= min_count),
            })
    return pd.DataFrame(rows)


def evaluate(flags: pd.DataFrame, spikes: list[dict], rule: str = "flag_z") -> dict:
    """Precision / recall of flagged (group, week) pairs vs planted spikes,
    plus Precision@k (k = number planted)."""
    planted = {(sp["cluster"], sp["week"]) for sp in spikes}
    flagged = {(r.group, r.week) for r in flags.itertuples() if getattr(r, rule)}
    tp = len(flagged & planted)
    top = flags.sort_values("z", ascending=False).head(len(planted))
    p_at_k = (sum((r.group, r.week) in planted for r in top.itertuples()) / len(planted)) if planted else float("nan")
    return {
        "tp": tp, "fp": len(flagged - planted), "fn": len(planted - flagged),
        "n_flagged": len(flagged),
        "precision": tp / len(flagged) if flagged else float("nan"),
        "recall": tp / len(planted) if planted else float("nan"),
        "precision_at_k": p_at_k,
    }


def top_spikes(flags: pd.DataFrame, rule: str = "flag_z", n: int = 10) -> pd.DataFrame:
    """The most severe current spikes, for the dashboard / Slack alert."""
    if flags.empty:
        return flags
    hit = flags[flags[rule]].sort_values("z", ascending=False).head(n)
    return hit.reset_index(drop=True)
