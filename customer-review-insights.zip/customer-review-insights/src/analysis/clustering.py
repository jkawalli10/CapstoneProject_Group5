"""Issue clustering: group negative reviews by the problem they describe.

Two embedding back-ends are supported:

* **Multilingual sentence embeddings** (``paraphrase-multilingual-MiniLM-L12-v2``)
  -- the production path. It places reviews from different languages that mean
  the same thing close together, which is the whole point of a multilingual
  issue taxonomy.
* **TF-IDF + SVD** -- a dependency-light fallback used when
  ``sentence-transformers`` is not installed (CI, quick local runs). It works
  well on the English translations produced by the translation stage.

Clustering is done with k-means (with a silhouette sweep over k) or HDBSCAN on a
PCA-reduced space. ``summarize`` reports cluster size, language mix and how well
each cluster aligns with the LLM-assigned topic (purity).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

EMBED_MODEL = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"


# --------------------------------------------------------------------------- #
# Embeddings
# --------------------------------------------------------------------------- #
def embed(texts: list[str], batch_size: int = 64, backend: str = "auto") -> np.ndarray:
    """Embed ``texts``; ``backend`` is ``auto`` | ``st`` | ``tfidf``."""
    if backend in ("auto", "st"):
        try:
            from sentence_transformers import SentenceTransformer

            model = SentenceTransformer(EMBED_MODEL)
            return model.encode(texts, batch_size=batch_size, normalize_embeddings=True,
                                show_progress_bar=False)
        except Exception:
            if backend == "st":
                raise
    return embed_tfidf(texts)


def embed_tfidf(texts: list[str], n_components: int = 128) -> np.ndarray:
    """Deterministic TF-IDF + SVD embedding (L2-normalised) as a fallback."""
    from sklearn.decomposition import TruncatedSVD
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.preprocessing import Normalizer

    X = TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=40000,
                        sublinear_tf=True, strip_accents="unicode").fit_transform(
        [t or "" for t in texts])
    k = min(n_components, max(2, X.shape[1] - 1), max(2, X.shape[0] - 1))
    reduced = TruncatedSVD(n_components=k, random_state=0).fit_transform(X)
    return Normalizer().fit_transform(reduced)


# --------------------------------------------------------------------------- #
# Clustering algorithms
# --------------------------------------------------------------------------- #
def kmeans_search(emb: np.ndarray, ks=range(6, 15), seed: int = 0):
    """Fit k-means for each k, return ``(best_labels, table of k / silhouette)``."""
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score

    rows, best = [], None
    for k in ks:
        labels = KMeans(n_clusters=k, n_init=10, random_state=seed).fit_predict(emb)
        sil = silhouette_score(emb, labels) if len(set(labels)) > 1 else float("nan")
        rows.append({"k": k, "silhouette": round(float(sil), 4)})
        if best is None or sil > best[0]:
            best = (sil, labels)
    return best[1], pd.DataFrame(rows)


def hdbscan_labels(emb: np.ndarray, min_cluster_size: int = 15, pca_dims: int = 20, seed: int = 0):
    """HDBSCAN on a PCA-reduced space (384-d embeddings are too sparse otherwise)."""
    from sklearn.cluster import HDBSCAN
    from sklearn.decomposition import PCA

    dims = min(pca_dims, emb.shape[1], max(2, emb.shape[0] - 1))
    reduced = PCA(n_components=dims, random_state=seed).fit_transform(emb)
    return HDBSCAN(min_cluster_size=min_cluster_size).fit_predict(reduced)


def cluster_reviews(df: pd.DataFrame, text_col: str = "translated_text", method: str = "kmeans",
                    k: int | None = None, backend: str = "auto", seed: int = 0) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Cluster reviews and return ``(df_with_cluster_id, silhouette_table)``."""
    texts = df[text_col].fillna(df.get("review_text", "")).astype(str).tolist()
    emb = embed(texts, backend=backend)
    sil_table = pd.DataFrame()
    if method == "hdbscan":
        labels = hdbscan_labels(emb, seed=seed)
    else:
        if k is None:
            labels, sil_table = kmeans_search(emb, seed=seed)
        else:
            from sklearn.cluster import KMeans

            labels = KMeans(n_clusters=k, n_init=10, random_state=seed).fit_predict(emb)
    out = df.copy()
    out["cluster_id"] = labels
    return out, sil_table


def summarize(df: pd.DataFrame, label_col: str = "cluster_id", topic_col: str = "topic") -> pd.DataFrame:
    """Per cluster: size, languages, dominant LLM topic and its share (purity)."""
    rows = []
    for c, g in df.groupby(label_col):
        top = g[topic_col].value_counts() if topic_col in g.columns else pd.Series(dtype=int)
        rows.append({
            "cluster": c,
            "size": len(g),
            "dominant_topic": top.index[0] if len(top) else None,
            "topic_purity": round(top.iloc[0] / len(g), 2) if len(top) else None,
            "languages": g.detected_language.value_counts().to_dict()
            if "detected_language" in g.columns else {},
        })
    return pd.DataFrame(rows).sort_values("size", ascending=False).reset_index(drop=True)


def label_clusters(df: pd.DataFrame, label_col: str = "cluster_id", n_examples: int = 8) -> dict[int, str]:
    """A short human label per cluster from its most frequent issue phrases."""
    labels: dict[int, str] = {}
    for c, g in df.groupby(label_col):
        if "issue" in g.columns and g["issue"].notna().any():
            top = g["issue"].value_counts().head(n_examples)
            labels[int(c)] = "; ".join(top.index[:3])
        else:
            labels[int(c)] = " ".join(" ".join(g["review_text"].head(3)).split())[:60]
    return labels
