"""A thin LLM client with a deterministic offline fallback.

The whole pipeline talks to an object that behaves like ``anthropic.Anthropic``:
it exposes ``client.messages.create(model=..., system=..., messages=[...],
max_tokens=...)`` and returns a response with ``.content[0].text`` and
``.usage.input_tokens`` / ``.usage.output_tokens``.

When no ``ANTHROPIC_API_KEY`` is configured (or ``OFFLINE=1``) the call is served
by :class:`OfflineEngine`, which produces plausible JSON for every prompt in the
project. That keeps the tests, the demo and the CI pipeline free and reliable,
while production simply sets a key and gets real Claude output.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Optional

from src import config


# --------------------------------------------------------------------------- #
# Response containers (mirror the Anthropic SDK shape)
# --------------------------------------------------------------------------- #
@dataclass
class _Block:
    text: str
    type: str = "text"


@dataclass
class _Usage:
    input_tokens: int
    output_tokens: int


@dataclass
class _Response:
    content: list
    usage: _Usage


# --------------------------------------------------------------------------- #
# Offline heuristics
# --------------------------------------------------------------------------- #
_NEG_WORDS = {
    "broke", "broken", "defect", "defective", "damaged", "late", "missing", "wrong",
    "poor", "terrible", "awful", "bad", "worst", "disappointed", "refund", "return",
    "useless", "cheap", "flimsy", "stopped", "doesn't work", "does not work", "not work",
    "waste", "scam", "never arrived", "faulty", "cracked", "leaked", "overpriced",
    "kaputt", "schlecht", "defekt", "mala", "malo", "roto", "retard", "cassé", "mauvais",
    "壊れ", "最悪", "ひどい", "悪い", "坏", "差", "垃圾", "失望",
}
_POS_WORDS = {
    "great", "excellent", "love", "perfect", "amazing", "fantastic", "good", "best",
    "happy", "recommend", "quality", "worth", "awesome", "superb", "delight", "wonderful",
    "super", "toll", "sehr gut", "genial", "excelente", "bueno", "perfecto", "génial",
    "素晴らしい", "良い", "最高", "满意", "很好", "棒", "喜欢",
}
_NEUTRAL_WORDS = {"okay", "ok", "average", "fine", "decent", "acceptable", "mixed", "so-so"}

_TOPIC_KEYWORDS = {
    "shipping": ["ship", "deliver", "parcel", "package", "arrive", "post", "courier", "lieferung", "envío", "livraison", "配送", "快递"],
    "quality": ["quality", "durab", "build", "material", "broke", "defect", "sturdy", "flimsy", "qualität", "calidad", "qualité", "品質", "质量"],
    "support": ["support", "service", "refund", "return", "customer care", "seller", "kundenservice", "atención", "service client", "客服", "售后"],
    "features": ["feature", "function", "size", "fit", "compatib", "design", "missing", "funktion", "tamaño", "taille", "功能", "尺寸"],
    "price": ["price", "cost", "expensive", "cheap", "value", "money", "preis", "precio", "prix", "价格", "贵"],
    "ux": ["easy", "setup", "instruction", "interface", "app", "use", "confus", "install", "bedienung", "fácil", "facile", "操作", "设置"],
}

_ISSUE_PATTERNS = [
    (["late", "delayed", "never arrived", "didn't arrive", "not arrived", "missing shipment"], "arrived late"),
    (["damaged", "crushed", "broken box", "cracked"], "package arrived damaged"),
    (["stopped working", "stopped", "no longer works", "died"], "stopped working after a short time"),
    (["wrong size", "doesn't fit", "too small", "too big", "undersized"], "wrong size, does not fit"),
    (["wrong item", "different item", "not what i ordered"], "wrong item received"),
    (["refund", "return refused", "no refund"], "refund refused by seller"),
    (["overpriced", "too expensive", "not worth the money", "not worth"], "overpriced for what it is"),
    (["poor quality", "flimsy", "cheap material", "fell apart"], "poor build quality"),
    (["battery", "charge", "drains"], "battery drains quickly"),
    (["not as described", "misleading", "different from the description"], "not as described"),
    (["missing parts", "missing piece", "assembly"], "missing parts"),
    (["connect", "wifi", "bluetooth", "signal"], "connectivity problems"),
]


def detect_language(text: str) -> str:
    """Cheap language detection good enough for the six project languages."""
    if re.search(r"[\u3040-\u30ff]", text):
        return "ja"
    if re.search(r"[\u4e00-\u9fff]", text):
        return "zh"
    low = text.lower()
    if re.search(r"[äöüß]", low) or any(w in low for w in ("und ", "nicht ", "sehr ", "ist ", "das ")):
        return "de"
    if re.search(r"[ñáéíóú¿¡]", low) or any(w in low for w in ("el ", "que ", "muy ", "pero ", "para ")):
        return "es"
    if re.search(r"[àâçéèêëîïôùûü]", low) or any(w in low for w in ("le ", "très ", "pas ", "mais ", "pour ")):
        return "fr"
    return "en"


def _score_sentiment(text: str) -> tuple[str, float, int]:
    low = text.lower()
    neg = sum(1 for w in _NEG_WORDS if w in low)
    pos = sum(1 for w in _POS_WORDS if w in low)
    neu = sum(1 for w in _NEUTRAL_WORDS if w in low)
    if neg > pos and neg >= 1:
        label, conf = "negative", min(0.6 + 0.1 * neg, 0.95)
        stars = 1 if neg >= 3 else 2
    elif pos > neg and pos >= 1:
        label, conf = "positive", min(0.6 + 0.1 * pos, 0.95)
        stars = 5 if pos >= 3 else 4
    elif neu:
        label, conf, stars = "neutral", 0.55, 3
    else:
        label, conf, stars = "neutral", 0.5, 3
    return label, conf, stars


def _score_topic(text: str) -> str:
    low = text.lower()
    best, best_hits = "other", 0
    for topic, kws in _TOPIC_KEYWORDS.items():
        hits = sum(1 for kw in kws if kw in low)
        if hits > best_hits:
            best, best_hits = topic, hits
    return best


def _extract_issue(text: str) -> str:
    low = text.lower()
    for keys, phrase in _ISSUE_PATTERNS:
        if any(k in low for k in keys):
            return phrase
    return "reported a problem with the product"


# --------------------------------------------------------------------------- #
# Offline engine
# --------------------------------------------------------------------------- #
class OfflineEngine:
    """Produces the exact JSON shapes the prompts ask for, with no API calls."""

    def create(self, *, model: str, system: str = "", messages: list, max_tokens: int = 512, **_: Any) -> _Response:
        user = messages[-1]["content"] if messages else ""
        try:
            payload = json.loads(user)
        except (json.JSONDecodeError, TypeError):
            payload = user

        if "translator" in system:
            text = self._translations(payload)
        elif "customer-experience analyst" in system:
            text = self._classifications(payload)
        elif "sort negative customer reviews" in system:
            text = self._assignments(payload)
        elif "negative customer reviews" in system and "issue" in system:
            text = self._issues(payload)
        elif "quality reviewer" in system or "strict quality reviewer" in system:
            text = self._judge(payload)
        elif "public replies" in system:
            text = self._reply(payload)
        else:
            text = json.dumps({"result": "offline"})

        return _Response(content=[_Block(text)], usage=_Usage(input_tokens=len(user) // 4 + 50,
                                                              output_tokens=len(text) // 4 + 20))

    # -- per-prompt handlers ------------------------------------------------- #
    def _translations(self, payload) -> str:
        items = []
        for r in payload:
            text = r["text"]
            lang = detect_language(text)
            english = text if lang == "en" else f"[EN] {text}"
            items.append({"id": r["id"], "language": lang, "english": english})
        return json.dumps({"translations": items}, ensure_ascii=False)

    def _classifications(self, payload) -> str:
        out = []
        for r in payload:
            label, conf, stars = _score_sentiment(r["text"])
            out.append({"id": r["id"], "sentiment": label, "topic": _score_topic(r["text"]),
                        "confidence": round(conf, 2), "stars": stars})
        return json.dumps({"classifications": out}, ensure_ascii=False)

    def _assignments(self, payload) -> str:
        out = []
        for r in payload:
            issue = _extract_issue(r["text"])
            category = self._category_for(issue)
            out.append({"id": r["id"], "issue": issue, "category": category})
        return json.dumps({"assignments": out}, ensure_ascii=False)

    def _issues(self, payload) -> str:
        return json.dumps({"issues": [{"id": r["id"], "issue": _extract_issue(r["text"])} for r in payload]},
                          ensure_ascii=False)

    def _judge(self, payload) -> str:
        reply = payload.get("reply", "")
        review = payload.get("review", "")
        # A simple rubric: reward specificity (shared words) and penalise promises.
        shared = len(set(re.findall(r"\w+", reply.lower())) & set(re.findall(r"\w+", review.lower())))
        specificity = 5 if shared >= 3 else 4 if shared >= 1 else 3
        promises = bool(re.search(r"refund|replace|discount|credit|compensat|will send|will deliver", reply.lower()))
        invents = bool(re.search(r"your order|tracking number|on \d{1,2} ", reply.lower()))
        scores = {"empathy": 4, "specificity": specificity, "correctness": 4 if not invents else 2,
                  "tone": 4, "promises_outcome": promises, "invents_facts": invents,
                  "wrong_language": False, "needs_human_attention": False,
                  "reason": "Offline heuristic score."}
        return json.dumps(scores, ensure_ascii=False)

    def _reply(self, payload) -> str:
        review = payload.get("review", "")
        name = payload.get("customer_name")
        sentiment = payload.get("sentiment", "neutral")
        issue = payload.get("issue")
        greeting = f"Hi {name}," if name else "Hello,"
        snippet = " ".join(review.split())[:80]
        if sentiment == "negative":
            body = (f"{greeting} we're sorry about the problem you described — {issue or snippet}. "
                    f"That is not the experience we want for you, and we would like to look into it. "
                    f"Please reach out to our customer care team at support@acme-store.example so we can help.")
        elif sentiment == "positive":
            body = (f"{greeting} thank you for the kind words about {snippet}. "
                    f"It is great to hear this worked well for you, and we hope to see you again soon.")
        else:
            body = (f"{greeting} thank you for the balanced feedback — {snippet}. "
                    f"We appreciate you sharing both sides, and you are welcome to contact our team at "
                    f"support@acme-store.example if you would like us to help further.")
        return json.dumps({"reply": body + "\n\nThe Acme Store Customer Care Team"}, ensure_ascii=False)

    @staticmethod
    def _category_for(issue: str) -> int:
        table = {
            "arrived late": 6, "package arrived damaged": 0, "stopped working after a short time": 2,
            "wrong size, does not fit": 12, "wrong item received": 7, "refund refused by seller": 6,
            "overpriced for what it is": 10, "poor build quality": 1, "battery drains quickly": 5,
            "not as described": 3, "missing parts": 11, "connectivity problems": 9,
        }
        return table.get(issue, -1)


# --------------------------------------------------------------------------- #
# Public client
# --------------------------------------------------------------------------- #
class LLMClient:
    """Wraps either the real Anthropic SDK or the offline engine."""

    def __init__(self, api_key: Optional[str] = None, force_offline: Optional[bool] = None):
        self.offline = (not config.llm_enabled()) if force_offline is None else force_offline
        self._real = None
        if not self.offline:
            try:
                import anthropic

                self._real = anthropic.Anthropic(api_key=api_key or config.ANTHROPIC_API_KEY)
            except Exception as exc:  # pragma: no cover - network/SDK issues
                self.offline = True
                self._real = None
                self._init_error = str(exc)
        self.messages = self

    def create(self, **kwargs) -> _Response:
        if self.offline:
            return OfflineEngine().create(**kwargs)
        return self._real.messages.create(**kwargs)


def get_client(force_offline: Optional[bool] = None) -> LLMClient:
    return LLMClient(force_offline=force_offline)


def parse_json(text: str) -> dict:
    """Parse model output, tolerating ```json fences."""
    return json.loads(re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip()))


def text_of(resp) -> str:
    """First text block of a response (Sonnet 5 may put a thinking block first)."""
    for block in resp.content:
        if getattr(block, "type", "text") == "text":
            return block.text
    return resp.content[0].text
