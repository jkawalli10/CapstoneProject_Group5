"""LLMOps: log every LLM call (prompt version, tokens, cost, latency) and enforce
a hard spend cap so a public demo cannot burn through the API credit.

Every call made through :class:`TrackedClient` is appended to
``data/processed/llm_calls.jsonl``. Offline calls are logged with ``cost_usd: 0``.
"""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

from src import config

LOG = Path(os.getenv("LLM_LOG_FILE", config.PROCESSED_DIR / "llm_calls.jsonl"))
_lock = threading.Lock()


class BudgetExceeded(Exception):
    """Raised when the spend cap has been reached."""


def cap_usd() -> float:
    return float(os.getenv("MAX_SPEND_USD", str(config.MAX_SPEND_USD)))


def cost_usd(model: str, tokens_in: int, tokens_out: int) -> float:
    pin, pout = config.PRICES.get(model, (2.0, 10.0))  # unknown model -> assume the dearer price
    return tokens_in / 1e6 * pin + tokens_out / 1e6 * pout


def spent_usd() -> float:
    if not LOG.exists():
        return 0.0
    total = 0.0
    for line in LOG.read_text(encoding="utf-8").splitlines():
        if line.strip():
            total += json.loads(line).get("cost_usd", 0.0)
    return total


class TrackedClient:
    """Drop-in wrapper around an :class:`~src.llmops.llm_client.LLMClient`."""

    def __init__(self, client, purpose: str, prompt_version: str):
        self._client = client
        self.purpose = purpose
        self.prompt_version = prompt_version
        self.messages = self

    def create(self, **kwargs):
        with _lock:
            if spent_usd() >= cap_usd():
                raise BudgetExceeded(f"spend cap of ${cap_usd():.2f} reached")
        t0 = time.time()
        resp = self._client.messages.create(**kwargs)
        rec = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "purpose": self.purpose,
            "prompt_version": self.prompt_version,
            "model": kwargs.get("model"),
            "tokens_in": resp.usage.input_tokens,
            "tokens_out": resp.usage.output_tokens,
            "latency_s": round(time.time() - t0, 3),
            "offline": getattr(self._client, "offline", False),
        }
        rec["cost_usd"] = 0.0 if rec["offline"] else round(
            cost_usd(rec["model"], rec["tokens_in"], rec["tokens_out"]), 6)
        with _lock:
            LOG.parent.mkdir(parents=True, exist_ok=True)
            with LOG.open("a", encoding="utf-8") as f:
                f.write(json.dumps(rec) + "\n")
        return resp
