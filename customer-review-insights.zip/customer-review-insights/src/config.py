"""Central configuration for the Customer Review Insights & Response Generator.

Everything that can be tuned lives here so the rest of the code stays small and
testable. Values come from environment variables (loaded from a local ``.env``
when present) with sensible defaults, so the project runs out of the box in
"offline" mode even without any API keys.
"""
from __future__ import annotations

import os
from pathlib import Path

try:  # python-dotenv is optional at import time
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # pragma: no cover - dotenv missing is not fatal
    pass

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #
ROOT = Path(__file__).resolve().parents[1]
PROMPTS_DIR = ROOT / "prompts"
DATA_DIR = ROOT / "data"
SAMPLES_DIR = DATA_DIR / "samples"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"

for _p in (SAMPLES_DIR, RAW_DIR, PROCESSED_DIR):
    _p.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------- #
# Languages and taxonomy
# --------------------------------------------------------------------------- #
LANGUAGES = ["en", "de", "es", "fr", "ja", "zh"]

LANGUAGE_NAMES = {
    "en": "English",
    "de": "German",
    "es": "Spanish",
    "fr": "French",
    "ja": "Japanese",
    "zh": "Chinese",
}

TOPICS = ["shipping", "quality", "support", "features", "price", "ux", "other"]

SENTIMENTS = ["negative", "neutral", "positive"]

# --------------------------------------------------------------------------- #
# LLM settings
# --------------------------------------------------------------------------- #
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
LLM_MODEL = os.getenv("CLAUDE_MODEL", "claude-haiku-4-5")
JUDGE_MODEL = os.getenv("JUDGE_MODEL", "claude-sonnet-5")

# When no key is present the code falls back to a deterministic offline engine so
# tests, the demo and the CI pipeline never depend on a paid API.
OFFLINE = os.getenv("OFFLINE", "auto").lower()  # auto | 1 | 0


def llm_enabled() -> bool:
    """True when a real LLM call should be attempted."""
    if OFFLINE == "1":
        return False
    if OFFLINE == "0":
        return True
    return bool(ANTHROPIC_API_KEY)


# USD per million tokens (input, output) for the models we use.
PRICES = {
    "claude-haiku-4-5": (1.0, 5.0),
    "claude-sonnet-5": (2.0, 10.0),
}

MAX_SPEND_USD = float(os.getenv("MAX_SPEND_USD", "1.0"))

# --------------------------------------------------------------------------- #
# Evaluation protocol
# --------------------------------------------------------------------------- #
# Star rating -> sentiment label used as ground truth.
STAR_TO_LABEL = {1: "negative", 2: "negative", 3: "neutral", 4: "positive", 5: "positive"}

# MARC corpus: 200k train / 5k validation / 5k test per language.
MARC_HF_TEMPLATE = "hf://datasets/mteb/amazon_reviews_multi/{lang}/{split}.jsonl"
MARC_SPLITS = ["train", "validation", "test"]

# Targets from the proposal.
TARGET_SENTIMENT_ACCURACY = 0.85
TARGET_HUMAN_ACCEPTANCE = 0.80
TARGET_REVIEWS_PER_DAY = 1000
